#!/usr/bin/env python

import smtplib
import os
import random
import time
import sys
import time
import optparse

class mm4_rbt(object):
   """MMS Client that connect to MM4 in order to send MM4 MMS messages and email messages"""

   def __init__(self):
      self.hostIp = None
      self.port = 0
      self.type = 0
      self.sender = None
      self.recipient = None

   def set_mm4_config(self, hostIP, port):
      self.hostIP = hostIP
      self.port = int(port)

   def mm4_fwd_req(self):
      print "Message type mm4 forward request";
      sender = self.sender
      receivers = self.recipient
      message = ("From: %s\r\nTo: %s\r\n" % (sender, receivers))
      message += "Message-Id: <201111291530.pATFUmGq019400@mms.millennium.com.lb>\r\n"
      message += "X-Mms-Originator-System: admin@enghouse.com\r\n"
      message += ("Sender: %s\r\n" % sender)
      message += "X-Mms-Expiry: Mon, 28 Nov 2011 23:00:40 GMT\r\n"
      message += "Date: Tue, 29 Nov 2011 17:19:52 +2000\r\n"
      message += ("Subject: %s\r\n" % self.subject)
      message += "X-Mms-3GPP-MMS-Version: 5.4.0\r\n"
      message += "X-Mms-Message-Type: MM4_forward.REQ\r\n"
      message += 'X-Mms-Transaction-ID: "579478452"\r\n'
      message += 'X-Mms-Message-ID: "5143@mms8072"\r\n'
      message += "X-Mms-Sender-Visibility: Show\r\n"
      message += "X-Mms-Delivery-Report: Yes\r\n"
      message += "X-Mms-Read-Reply: Yes\r\n"
      message += "X-Mms-Priority: Normal\r\n"
      message += "X-Mms-Ack-Request: Yes\r\n"
      message += "X-Mms-Message-Class: Personal\r\n"
      message += "X-Mms-Content-Location: id=xxxxxx\r\n"
      message += "Content-Type: text/plain\r\n"
      message += "\r\n"
      message = message + 'This is an MM4 forward Req Message.'
      print sender
      return message

   def mm4_fwd_res(self):
      print "Message type mm4 forward response";
      sender = self.sender
      receivers = self.recipient
      message = ("Sender: %s\r\nTo: %s\r\n" % (sender, receivers))
      message += "Message-Id: <201111291530.pATFUmGq019400@mms.millennium.com.lb>\r\n"
      message += "Date: Tue, 29 Nov 2011 17:19:52 +2000\r\n"
      message += "X-Mms-3GPP-MMS-Version: 5.4.0\r\n"
      message += "X-Mms-Message-Type: MM4_forward.RES\r\n"
      message += "X-Mms-Transaction-ID: '579478452'\r\n"
      message += 'X-Mms-Message-ID: "5143@mms8072"\r\n'
      message += "X-Mms-Request-Status-Code: Ok\r\n"
      message += "Content-Type: text/plain\r\n"
      message += "\r\n"
      message = message + 'This is an MM4 Forward Response Message.'
      return message

   def mm4_del_req(self):
      print "Message type mm4 delivery report request";
      sender = self.sender
      receivers = self.recipient
      message = ("From: %s\r\nTo: %s\r\n" % (sender, receivers))
      message += "Message-Id: <201111291530.pATFUmGq019400@mms.millennium.com.lb>\r\n"
      message += ("Sender: %s\r\n" % sender)
      message += "Date: Tue, 29 Nov 2011 17:19:52 +2000\r\n"
      message += "X-Mms-3GPP-MMS-Version: 5.4.0\r\n"
      message += "X-Mms-Message-Type: MM4_delivery_report.REQ\r\n"
      message += 'X-Mms-Transaction-ID: "579478452"\r\n'
      message += 'X-Mms-Message-ID: "5143@mms8072"\r\n'
      message += "X-Mms-Ack-Request: Yes\r\n"
      message += "X-Mms-MM-Status-Code: Retrieved\r\n"
      message += "Content-Type: text/plain\r\n"
      message += "\r\n"
      message = message + 'This is an MM4 Delivery Req Message.'
      return message

   def mm4_del_res(self):
      print "Message type mm4 delivery report response";
      sender = self.sender
      receivers = self.recipient
      message = ("Sender: %s\r\nTo: %s\r\n" % (sender, receivers))
      message += "Message-Id: <201111291530.pATFUmGq019400@mms.millennium.com.lb>\r\n"
      message += "Date: Tue, 29 Nov 2011 17:19:52 +2000\r\n"
      message += "X-Mms-3GPP-MMS-Version: 5.4.0\r\n"
      message += "X-Mms-Message-Type: MM4_delivery_report.RES\r\n"
      message += 'X-Mms-Transaction-ID: "579478452"\r\n'
      message += 'X-Mms-Message-ID: "5143@mms8072"\r\n'
      message += "X-Mms-Request-Status-Code: Ok\r\n"
      message += "Content-Type: text/plain\r\n"
      message += "\r\n"
      message = message + 'This is an MM4 Delivery Response Message.'
      return message

   def mm4_read_req(self):
      print "Message type mm4 readreply request";
      sender = self.sender
      receivers = self.recipient
      message = ("From: %s\r\nTo: %s\r\n" % (sender, receivers))
      message += "Message-Id: <201111291530.pATFUmGq019400@mms.millennium.com.lb>\r\n"
      message += ("Sender: %s\r\n" % sender)
      message += "Date: Tue, 29 Nov 2011 17:19:52 +2000\r\n"
      message += "X-Mms-3GPP-MMS-Version: 5.4.0\r\n"
      message += "X-Mms-Message-Type: MM4_read_reply_report.REQ\r\n"
      message += 'X-Mms-Transaction-ID: "579478452"\r\n'
      message += 'X-Mms-Message-ID: "5143@mms8072"\r\n'
      message += "X-Mms-Ack-Request: Yes\r\n"
      message += "X-Mms-Read-Status: Read\r\n"
      message += "Content-Type: text/plain\r\n"
      message += "\r\n"
      message = message + 'This is an MM4 Delivert Request Message.'
      return message

   def mm4_read_res(self):
      print "Message type mm4 readreply response";
      sender = self.sender
      receivers = self.recipient
      message = ("Sender: %s\r\nTo: %s\r\n" % (sender, receivers))
      message += "Message-Id: <201111291530.pATFUmGq019400@mms.millennium.com.lb>\r\n"
      message += "X-Mms-Originator-System: admin@mms-1.millennium.com.lb\r\n"
      message += "X-Mms-Expiry: Mon, 28 Nov 2011 23:00:40 GMT\r\n"
      message += "Date: Tue, 29 Nov 2011 17:19:52 +2000\r\n"
      message += "Subject: =?utf-8?B?VGhpcyBpcyBhbiBtbXMgdGVzdA==?=\r\n"
      message += "X-Mms-3GPP-MMS-Version: 5.4.0\r\n"
      message += "X-Mms-Message-Type: MM4_read_reply_report.RES\r\n"
      message += 'X-Mms-Transaction-ID: "579478452"\r\n'
      message += 'X-Mms-Message-ID: "5143@mms8072"\r\n'
      message += "Content-Type: text/plain\r\n"
      message += "\r\n"
      message = message + 'This is an MM4 Read Response Message.'
      return message

   def mm3(self):
      print "Message type mm3 submit request";
      sender = self.sender
      receivers = self.recipient
      subject = self.subject
      message = ("From: %s\r\nTo: %s\r\n" % (sender, receivers))
      base64_subject = subject.encode('utf-8')
      message += ("Subject: =?utf-8?B?%s?=\r\n" % (base64_subject))
      message += "\r\n"
      message += 'This is a test e-mail message.'
      return message

   def create_mm4_message(self, sender, recipient, subject, type):
      self.sender = sender
      self.recipient = recipient
      self.subject = subject

      options = { 0:self.mm4_fwd_req,
                  1:self.mm4_fwd_res,
                  2:self.mm4_del_req,
                  3:self.mm4_del_res,
                  4:self.mm4_read_req,
                  5:self.mm4_read_res,
                  6:self.mm3
                }
      # Get the function for the specified case or use default if not found
      selected_case = options.get(type, 0)
      result = selected_case()
      return result

   def send_mm4_message(self, sender, recipients, message):
      try:
         server = smtplib.SMTP(self.hostIP, self.port)
         server.sendmail(sender, recipients.split(","),message)
         server.quit()    
         print "Successfully sent email"
      except smtplib.SMTPException:
         print "Error: unable to send email"
      
def parse_arguments():
  parser = optparse.OptionParser(description='MM4 script for sending MMS messages from foreign MMSC or from an Email.')

  type_help_str = """Specify the message type:                       
     0 - mm4 forward req                                  
     1 - mm4 forward res                               
     2 - mm4 delivery req                             
     3 - mm4 delivery res                                     
     4 - mm4 readreply req                                  
     5 - mm4 readreply res                                       
     6 - mm3
  """

  # Add required arguments
  parser.add_option('-o', '--sender', dest='sender', help='Sender of the message')
  parser.add_option('-r', '--recipient', dest='recipient', help='Recipient of the message')
  parser.add_option('-H', '--host', dest='host', help='MMSC Host')
  parser.add_option('-p', '--port', dest='port', help='Port for the message')
  parser.add_option('-s', '--subject', dest='subject', help='Subject of the message')
  parser.add_option('-t', '--type', dest='type', help=type_help_str)

  # Parse command-line arguments
  args, _ = parser.parse_args()

  # Check if required arguments are provided
  if not all([args.sender, args.recipient, args.port, args.subject, args.sender, args.host, args.type]):
    print("Error: Missing required arguments.")
    parser.print_help()
    sys.exit(1)

  return args

if __name__ == "__main__":
   # Parse command-line arguments
   args = parse_arguments()

   # Access the arguments
   sender = args.sender
   recipient = args.recipient
   host = args.host
   port = args.port
   subject = args.subject
   type = args.type

   # Your logic to use the arguments goes here
   print("Sender:", sender)
   print("Recipient:", recipient)
   print("Host:", host)
   print("Port:", port)
   print("Subject:", subject)
   print("Type:", type)

   mm4_sim = mm4_rbt()

   mm4_sim.set_mm4_config(host, port)
   message = mm4_sim.create_mm4_message(sender, recipient, subject, int(type))
   mm4_sim.send_mm4_message(sender, recipient, message)

