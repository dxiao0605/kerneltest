


JINNY_LIB = "/home/jinny/automation_fw/robot-lib"
import sys
sys.path.append(JINNY_LIB) 

import email
import mms.email.MultiPartEmail as MultiPartEmail

def getDefaultMessage(fromAddress = '12456@jinny.ie', toAddress = '9613155662@jinnysoftware.com', subject = 'mm4 subject', message = 'test mm4 mesage', charset = "ISO-8859-1", mimeVersion = "1.0", cte = '7bit', mmsMessageType = "MM4_forward.REQ", mmsTransactionId = '634', mmsMesssageId = '566', messageTypeMm4 = True):
   '''Create the payload for a MM4 message. Examples of mmsMessageType are MM4_forward.REQ, MM4_delivery_report.REQ, MM4_read_reply_report.REQ, MM4_read_reply_report.REQ'''
   msg = email.Message.Message()
   msg = MultiPartEmail.MultiPartEmail(to = [toAddress], fromfield=fromAddress, subject = subject)
   msg.addHeader(headerName = "MIME-Version", headerValue=mimeVersion)
   msg.addHeader(headerName = "Content-Transfer-Encoding", headerValue=cte)
   if messageTypeMm4:
      msg.addHeader(headerName = "X-MMS-3GPP-MMS-version", headerValue="5.2.0")
      msg.addHeader(headerName = "X-MMS-Message-Type", headerValue=mmsMessageType)
      msg.addHeader(headerName = "X-MMS-Transaction-ID", headerValue=mmsTransactionId)
      msg.addHeader(headerName = "X-MMS-Message-ID", headerValue=mmsMesssageId)

   msg.addContent("attachment.txt", message)
   return msg


