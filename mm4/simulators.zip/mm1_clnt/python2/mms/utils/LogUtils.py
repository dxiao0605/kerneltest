import sys
import logging
import testConfig
import systemConfig

log = None

def makeDefaultLogger(fileName = None):
   print "\n#################################\ncalled makeDefaultLogger()"
   global log
   if log == None:
      handler = logging.StreamHandler(sys.stdout)
      fmt = logging.Formatter(testConfig.defaultLoggingFormat, None)
      handler.setFormatter(fmt)
      logging.getLogger("default").addHandler(handler)
      log = logging.getLogger("default")
#     log.setLevel(logging.DEBUG)
      log.setLevel(systemConfig.logLevel)
   return log

