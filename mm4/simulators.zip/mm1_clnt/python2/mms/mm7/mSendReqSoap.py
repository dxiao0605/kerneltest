import string

mSendReqSoapOrig = """\
<?xml version='1.0' ?><env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/"><env:Header><mm7:TransactionID xmlns:mm7="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">2c35e:11492f0feda:-7da3vas-apps1.vodacom4me.co.za/10.113.18.67</mm7:TransactionID></env:Header><env:Body><SubmitReq xmlns="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3"><MM7Version>5.3.0</MM7Version><SenderIdentification><VASPID>mm7test</VASPID><SenderAddress><Number>27820099820</Number></SenderAddress></SenderIdentification><Recipients><To><Number>27820819370</Number></To></Recipients><ExpiryDate>2007-08-29T14:04:31+02:00</ExpiryDate><DeliveryReport>false</DeliveryReport><Priority>Low</Priority><Subject>George Victoria Bay</Subject><Content href="cid:A0" /></SubmitReq></env:Body></env:Envelope>
"""
mSendReqSoapOrigFormatted = """\
<?xml version='1.0' ?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
<env:Header>
  <mm7:TransactionID xmlns:mm7="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">2c35e:11492f0feda:-7da3vas-apps1.vodacom4me.co.za/10.113.18.67</mm7:TransactionID>
</env:Header>
<env:Body>
  <SubmitReq xmlns="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
     <MM7Version>5.3.0</MM7Version>
     <SenderIdentification>
        <VASPID>mm7test</VASPID>
        <SenderAddress>
           <Number>27820099820</Number>
        </SenderAddress>
      </SenderIdentification>
      <Recipients>
         <To>
            <Number>27820819370</Number>
         </To>
      </Recipients>
      <ExpiryDate>2007-08-29T14:04:31+02:00</ExpiryDate>
      <DeliveryReport>false</DeliveryReport>
      <Priority>Low</Priority>
      <Subject>George Victoria Bay</Subject>
      <Content href="cid:A0"/>
   </SubmitReq>
</env:Body>
</env:Envelope>
"""

mSendResSoapOrig = """\
    <?xml
        version="1.0"
        encoding="UTF-8"
        ?>
    <E:Envelope
        xmlns:E="http://schemas.xmlsoap.org/soap/envelope/"
        xmlns:s="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:y="http://www.w3.org/2001/XMLSchema">
        <E:Header>
            <ns1:TransactionID
                xmlns:ns1="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
                2c35e:11492f0feda:-7da3vas-apps1.vodacom4me.co.za/10.113.18.67
                </ns1:TransactionID>
            </E:Header>
        <E:Body>
            <m:SubmitRsp
                xmlns:m="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
                <MM7Version>
                    5.3.0
                    </MM7Version>
                <Status>
                    <StatusCode>
                        1000
                        </StatusCode>
                    </Status>
                <MessageID>
                    Q0bSvc8AAiyRAIXAqAJ2
                    </MessageID>
                </m:SubmitRsp>
            </E:Body>
        </E:Envelope>
"""

mSendReqSoap = string.Template('''\
<?xml version='1.0' ?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
<env:Header>
  <mm7:TransactionID xmlns:mm7="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/$transactionIdSchema"> $transactionId </mm7:TransactionID>
</env:Header>
<env:Body>
  <SubmitReq xmlns="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/$submitReqSchema">
     <MM7Version>$mm7Version</MM7Version>
     <SenderIdentification>
        <VASPID>$vaspId</VASPID>
        <SenderAddress>
           <Number>$senderAddress</Number>
        </SenderAddress>
      </SenderIdentification>
      <Recipients>
         $recipientAddresses
      </Recipients>
      <ExpiryDate>2009-08-29T14:04:31+02:00</ExpiryDate>
      <DeliveryReport>false</DeliveryReport>
      <Priority>Low</Priority>
      <Subject>$subject</Subject>
      <Content href="cid:A0"/>
   </SubmitReq>
</env:Body>
</env:Envelope>
''')
defaultMSendReqSoap = mSendReqSoap.substitute(
         transactionId = "defaultTransactionId",
         vaspId = "mm7test",
         senderAddress =    "3538690000000",
         recipientAddresses = "<To><Number>3538690000001</Number></To>",
         subject = "default subject",
         transactionIdSchema = "REL-5-MM7-1-3",
         submitReqSchema = "REL-5-MM7-1-3",
         mm7Version = "5.3.1",
)


mSendResSoap =  string.Template('''\
<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
<env:Header>
   <ns1:TransactionID
                xmlns:ns1="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
                $transactionId
   </ns1:TransactionID>
</env:Header>
<env:Body>
   <m:SubmitRsp
                xmlns:m="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
      <MM7Version>
                    5.3.0
      </MM7Version>
      <Status>
         <StatusCode>
            $statusCode
         </StatusCode>
      </Status>
      <MessageID>
         $messageId
      </MessageID>
   </m:SubmitRsp>
</env:Body>
</env:Envelope>''')
mSendResSoap =  string.Template('''\
<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
<env:Header>
<mm7:TransactionID xmlns:mm7="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3" env:mustUnderstand="1"> $transactionId </mm7:TransactionID>
</env:Header>
<env:Body>
<SubmitRsp xmlns="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
<MM7Version>5.6.0</MM7Version>
<Status>
<StatusCode>$statusCode</StatusCode>
<StatusText>Default status text</StatusText>
</Status>
      <MessageID>
         $messageId
      </MessageID>
</SubmitRsp>
</env:Body>
</env:Envelope>''')

def getMSendReqSoap(
         transactionId = "defaultTransactionId",
         vaspId = "mm7test",
         senderAddress =    "3538690000000",
         recipientAddresses = ["3538690000001","3538690000002"],
         subject = "default subject",
         transactionIdSchema = "REL-5-MM7-1-3",
         submitReqSchema = "REL-5-MM7-1-3",
         mm7Version = "5.3.1"):
   recipientAddressesString = "<To>"
   for r in recipientAddresses:
      recipientAddressesString += "<Number>" + r + "</Number>"
   recipientAddressesString += "</To>"
   mSendReq = mSendReqSoap.substitute(
         transactionId = transactionId,
         vaspId = vaspId,
         senderAddress = senderAddress, 
         recipientAddresses = recipientAddressesString,
         subject = subject,
         transactionIdSchema = transactionIdSchema,
         submitReqSchema = submitReqSchema,
         mm7Version = mm7Version,
   )
   return mSendReq

def getMSendResSoap(
                    transactionId = "defaultTransactionId",
                    statusCode = "1000",
                    messageId = "defaultMessageId"):
   mSendRes = mSendResSoap.substitute(
                    transactionId = transactionId,
                    statusCode = statusCode,
                    messageId = messageId)
   mSendResOrig ="""\
<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
<env:Header>
<mm7:TransactionID xmlns:mm7="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3" env:mustUnderstand="1"> defaultTransactionId </mm7:TransactionID>
</env:Header>
<env:Body>
<SubmitRsp xmlns="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-3">
<MM7Version>5.6.0</MM7Version>
<Status>
<StatusCode>9999</StatusCode>
<StatusText>Default status text</StatusText>
</Status>
<MessageID/>
</SubmitRsp>
</env:Body>
</env:Envelope>"""
   mSendResDarrel = """\
<?xml version="1.0" encoding="UTF-8"?>
<env:Envelope xmlns:env="http://schemas.xmlsoap.org/soap/envelope/">
<env:Header>
<mm7:TransactionID xmlns:mm7="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-2" env:mustUnderstand="1"> defaultTransactionId </mm7:TransactionID>
</env:Header>
<env:Body>
<SubmitRsp xmlns="http://www.3gpp.org/ftp/Specs/archive/23_series/23.140/schema/REL-5-MM7-1-2">
<MM7Version>5.3.0</MM7Version>
<Status>
<StatusCode>1001</StatusCode>
<StatusText>Default status text</StatusText>
</Status>
<MessageID/>
</SubmitRsp>
</env:Body>
</env:Envelope>"""



   return  mSendRes
   

mSendResDefault = mSendResSoap.substitute(
                    transactionId = "defaultTransactionId",
                    statusCode = "1000",
                    messageId = "defaultMessageId",
)


if __name__ == '__main__':
   print getMSendReqSoap()
   print getMSendResSoap()
   
