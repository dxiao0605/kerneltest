mm1TestWaitTime = 1 # wait 1 second
defaultSmtpSleepTime = 0.2
defaultMm1SleepTime = 3
import logging
#logLevel = logging.DEBUG
logLevel = logging.DEBUG


# ACTION: update the etc/controllerConfig.xml setting the traps elemenet to include your machine
# and your snmpTrapListenPort value, eg
# <traps notificationTargets="127.0.0.1/27630:10.10.10.39/27029" sendAlreadyNotifiedEvents="false"/>

tcpPortOffset = 41000
tprMachine = "10.10.10.211"
tprMachine = "10.10.60.2"
tprMachine = "10.10.11.18"
tprMachine = "10.10.11.42"

localSystemmfeuser2_intel_test =\
                  { "ip"                         : "10.10.10.39",
                    "hostname"                   : "intel-test",
                    "tcpPortOffset"              : tcpPortOffset,
                   "smppNotificationPort"       : tcpPortOffset + 99,
                   "smtpServerPort"             : tcpPortOffset + 1, 
                   "smtpPerformanceServerPort"  : tcpPortOffset + 101, 
                   "smtpNotificationServerPort" : tcpPortOffset + 98, 
                   "smtpDuplicateServerPort"    : tcpPortOffset + 97, 
                   "smtpQuarantineServerPort"   : tcpPortOffset + 96, 
                   "snmpTrapListenPort"         : tcpPortOffset + 11,
                   "mmscListenPort"             : tcpPortOffset + 0,
                  }

localSystem = localSystemmfeuser2_intel_test

buildSystem =\
                  { "ip" 		: "10.10.10.95",  # tupac
                    "username" 		: "colm", 
                    "password"		: "password", 
#                    "buildLocation"	: "/work/build/cruisecontrol-bin-2.6.1/projects/mfe2.4/Mfe_2.4_RedHatEnterpriseLinux4_latest.tar.gz"}
#                   "buildLocation"	: "/work/nightlyBuilds/build/Mfe_2.5_RedHatEnterpriseLinux4_latest.tar.gz"}
#                   "buildLocation"	: "/work/release/Mfe/Mfe_2.4_iter23g_RedHatEnterpriseLinux4.tar.gz"}
                    "buildLocation"	: "/work/nightlyBuilds/build/Mfe_2.5_RedHatEnterpriseLinux4_latest.tar.gz"}

 

mfeSystem_mark = \
            { "ip" : "10.10.10.29",
              "mmscPort"     : tcpPortOffset + 0,
              "emailPort"    : tcpPortOffset + 2,
              "numPids"      : 5,
              "mfeUsername"  : "adaptive",
              "mfePassword"  : "ad",
              "rootPassword" : "Passw0rd",
              "dbName"       : "orcl",
              "dbType"       : "RAMDB",
              "dbUserName"   : "am_engine_user",
              "dbPassword"   : "pushstart",
              "dbPrimaryServer" : "10.10.10.209",
              "dbFailoverServer" : "10.10.10.209", 
              "version"      : 2.7,
              "activeMqPort" : "60291",
              "siblings" : ["10.10.10.209"],
              }

mfeSystem_acta_blade4 = \
            { "ip" : "10.10.10.29",
              "mmscPort"     : tcpPortOffset + 0,
              "emailPort"    : tcpPortOffset + 2,
              "numPids"      : 5,
              "mfeUsername"  : "adaptive",
              "mfePassword"  : "ad",
              "rootPassword" : "Passw0rd",
              "dbName"       : "am_engine_user",
              "dbType"       : "RAMDB",
#             "dbType"       : "MYSQL",
              "dbUserName"   : "am_engine_user",
              "dbPassword"   : "pushstart",
              "dbPrimaryServer" : "10.10.10.29",
              "dbFailoverServer" : "10.10.10.29", 
              "version"      : 2.721,
#             "version"      : 2.5,
              "activeMqPort" : "60291",
#             "siblings" : ["10.10.10.28"],
              }

mfeSystem_acta_blade4_2_5 = \
            { "ip" : "10.10.10.29",
              "mmscPort"     : tcpPortOffset + 0,
              "emailPort"    : tcpPortOffset + 2,
              "numPids"      : 5,
              "mfeUsername"  : "adaptive",
              "mfePassword"  : "ad",
              "rootPassword" : "Passw0rd",
              "dbName"       : "am_engine_user",
              "dbType"       : "MYSQL",
              "dbUserName"   : "am_engine_user",
              "dbPassword"   : "pushstart",
              "dbPrimaryServer" : "10.10.10.29",
              "dbFailoverServer" : "10.10.10.29", 
              "version"      : 2.5,
              "activeMqPort" : "60291",
#             "siblings" : ["10.10.10.28"],
              }
mfeSystem_hpblade = \
            { "ip" : "10.10.12.93",
              "mmscPort"     : tcpPortOffset + 0,
              "emailPort"    : tcpPortOffset + 2,
              "numPids"      : 5,
              "mfeUsername"  : "adaptive",
              "mfePassword"  : "ad",
              "rootPassword" : "Passw0rd",
              "dbName"       : "orcl",
              "dbType"       : "RAMDB",
              "dbUserName"   : "am_engine_user",
              "dbPassword"   : "pushstart",
              "dbPrimaryServer" : "10.10.12.93",
              "dbFailoverServer" : "10.10.12.93", 
              "version"      : 2.7,
              "activeMqPort" : "6029",
#             "siblings" : ["10.10.10.28"],
              }
#mfeSystem = mfeSystem_hpblade 


mfeSystem_hpblade = \
            { "ip" : "10.10.12.93",
              "mmscPort"     : tcpPortOffset + 0,
              "emailPort"    : tcpPortOffset + 2,
              "numPids"      : 5,
              "mfeUsername"  : "adaptive",
              "mfePassword"  : "ad",
              "rootPassword" : "password",
              "dbName"       : "AM_ENGINE_USER",
              "dbType"       : "RAMDB",
              "dbUserName"   : "am_engine_user",
              "dbPassword"   : "pushstart",
              "dbPrimaryServer" : "10.10.12.93",
              "dbFailoverServer" : "10.10.12.93",
              "version"      :2.72,
}

mfeSystem = mfeSystem_acta_blade4
mfeSystem = mfeSystem_acta_blade4_2_5
mfeSystem = mfeSystem_hpblade


mfeMm1Url = "http://%s:%d/mms" % ( mfeSystem["ip"],tcpPortOffset + 0)
testMmscUrl = "%s:%d/mms" % (localSystem["ip"], tcpPortOffset + 0)

if __name__ == '__main__':
   print "details of mfeSystem are:\n%s" % mfeSystem

