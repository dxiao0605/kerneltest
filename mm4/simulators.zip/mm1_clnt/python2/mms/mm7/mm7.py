import time
import os
import re
import sys
import pdb
import smtplib
import email
from email.MIMEText import MIMEText
from email.MIMEMultipart import MIMEMultipart

JINNY_LIB = "/home/jinny/automation_fw/robot-lib"
import sys
sys.path.append(JINNY_LIB) 

#import testConfig
import mSendReqSoap
import mms.email.MultiPartEmail as MultiPartEmail
import mms.mm1.mm1 as mm1 
import base64
import string

class MM7(MultiPartEmail.MultiPartEmail):
   def __init__(self,to=['9613805822'],fromfield=" ",message_id=" ", subject = " ", subtype='mixed', username = " ", transactionId = "defaultTransactionId", httpVersion = "1.0", nestedContainers = True, log = None, soapAttach = None):
      self.log = log
      self.topContainer = MIMEMultipart(_subtype = subtype, boundary="===============4465919597934615333==")
      self.transactionId = transactionId
      self.httpVersion = httpVersion
      self.nestedContainers = nestedContainers
      self.messageString = None

      del self.topContainer["MIME-Version"]


      if soapAttach == None:
         soapAttach =  email.MIMENonMultipart.MIMENonMultipart("text/xml;","charset=us-ascii")
      soapAttach.set_payload(mSendReqSoap.getMSendReqSoap( 
         transactionId = self.transactionId,
         senderAddress = fromfield,
         recipientAddresses = to,
         subject = subject))
      soapAttach.add_header("Content-Transfer-Encoding","7bit")
      soapAttach.add_header("Content-ID","<mm7_msg>")
      self.topContainer.attach(soapAttach)
      self.message= MIMEMultipart(_subtype = subtype)
      self.message.add_header("Content-ID", "<A0>")

   def set_payload(self,payload, encoding=None):
      assert False, "method not implemented"

   def as_string(self):
      return self.getBody()

   def getBody(self):
      if self.messageString == None:  # avoid multiple calls causing attachments to be readded
         if self.nestedContainers == True:
            self.topContainer.attach(self.message)
         else:
            for a in self.message._payload:
               self.log.debug("adding attachment to the message: %s" % a)
               self.topContainer.attach(a)
         self.messageString = self.topContainer.as_string()
         self.messageString = re.sub("\r\n","\n", self.messageString)
         self.messageString = re.sub("\n","\r\n", self.messageString)
      return self.messageString

   def get(self):
      return self.as_string()

   def getResponse(self, statusCode = 1000, transactionId = None, messageId = "defaultMessageId", httpReturnCode = 200, httpReturnString = "OK"):
      if transactionId == None:
         transactionId = self.transactionId
      soapPart = mSendReqSoap.getMSendResSoap(statusCode = "%d" % statusCode, transactionId = transactionId, messageId = messageId)
      httpHeader = "HTTP/%s %d %s\r\nConnection: close\r\nContent-Type: text/xml; charset=\"utf-8\"\r\nContent-Length: %d\r\n\r\n" % (self.httpVersion, httpReturnCode, httpReturnString, len(soapPart))
      httpResponse = httpHeader + soapPart
      #     self.log.debug("generated the following response:\n%s" % httpResponse)
      return httpResponse

class MM7Client(mm1.HttpClient):

   def __init__(self, log = None, ip = None, port = None, headers = None):
      self.log = log
      self.soc = None
      self.ip = ip
      self.port = port
      if headers == None:
         self.headers = {"Content-type": "multipart/related",
                         "Accept": "text/plain",
                         "SOAPAction": "\"\"",
                 }

   def execute(self, msg, headers = {}, path = "/mm7/", returnResponse = True ):
      import httplib
      conn = httplib.HTTPConnection(self.ip, port = self.port)
      fullHeaders = {}
      fullHeaders.update(self.headers)
      fullHeaders.update(headers)
      conn.request("POST", path, msg.getBody(), fullHeaders)
      r1 = conn.getresponse()
      responseData = r1.read()
      self.log.debug("response status = %s, response reason %s response data %s" % (r1.status, r1.reason, responseData))
      fullResponse =  "%d " % r1.status + r1.reason + "%s\n" % r1.msg.headers +  responseData

      self.log.debug("\n\n\nfull response = [[%s]]" % fullResponse)
      return fullResponse

   if __name__ == '__main__':
      import mms.utils.LogUtils as LogUtils
      import optparse
      p = optparse.OptionParser()
      p.add_option("-d","--destIp",action = "store", type="string", dest= "destIp")
      p.add_option("-p","--port",action = "store", type="int", dest= "port")
      p.add_option("-c","--count",action = "store", type="int", dest= "count")
      p.add_option("-t","--timeDelay",action = "store", type="float", dest= "timeDelay")
      #p.set_defaults(destIp= "10.10.10.39", port = 11999, count = 1, timeDelay = 1)
      p.set_defaults(destIp= "192.168.250.228", port = 8072, count = 1, timeDelay = 1)
      opt,args = p.parse_args()

      #print "sending mm7 message to %s:%d" % (opt.destIp,opt.port)

      log = LogUtils.makeDefaultLogger()
      #msg = MM7()
      #msg.addContentFromFile(testConfig.cleanImage)
      #msg.addContentFromFile(testConfig.cleanText)
      #print "created the following MM7 message:\n%s" % msg.as_string()
      #print "created the following MM7 response:\n%s" % msg.getResponse()

      #base64 encode the username and password
      #auth = base64.encodestring('%s:%s' % ('mm7test', 'mm7test')).replace('\n', '')

      #print "auth is################:\n%s"%auth

      #import httplib
      #headers = {"Content-type": "multipart/related",
      #           "Accept": "text/plain",
      #           "SOAPAction": "\"\"",
      #           "Authorization": "Basic %s" % auth,
     # }

      # for i in xrange(opt.count):
      #    print "sending message %d" % i
      #    conn = httplib.HTTPConnection(opt.destIp, port = opt.port)
      #    conn.request("POST", "/mm7/mm7tomms_x.fcgi.sh", msg.getBody(), headers)
      #    r1 = conn.getresponse()
      #    data = r1.read()
      #    time.sleep(opt.timeDelay)

      # print "status = %s reason = %s " % (r1.status, r1.reason)
      # print "response dict = %s" % r1.__dict__
      # print "response msg headers = %s" % r1.msg.__dict__
      # print "len = %s" % r1.length
      # print "\n\n\ndata = [[[[%s]]]]" % data

