import os, popen2, logging

intlPrefix = "353"
operatorPrefix = "86"

import systemConfig

try:
   systemConfig.mfeSystem["version"]
except:
   # pick a very high version number
   systemConfig.mfeSystem["version"] = 10.0
try:
   systemConfig.mfeSystem["configLocation"]
except:
   systemConfig.mfeSystem["configLocation"] = "/etc/ams/mfe"
try:
   systemConfig.mfeSystem["siblings"]
except:
   systemConfig.mfeSystem["siblings"] = []
try:
   systemConfig.mfeSystem["activeMqPort"]
except:
   systemConfig.mfeSystem["activeMqPort"] = "6029"

try:
   systemConfig.logLevel
except:
   systemConfig.logLevel = logging.DEBUG


try:
   systemConfig.tprMachine
except:
   systemConfig.tprMachine = "10.10.10.211"
   systemConfig.tprMachine = "10.10.11.15"
   systemConfig.tprMachine = "10.10.11.42"


if systemConfig.mfeSystem["version"] < 2.7:
   defaultRootProfilename = "All Groups"
elif systemConfig.mfeSystem["version"] < 2.72:
   defaultRootProfilename = "Grp0"
else:
   defaultRootProfilename = "grp0"

#if systemConfig.mfeSystem["version"] < 2.8:
#   ramdbSchemaVersion = "2.7"
#elif systemConfig.mfeSystem["version"] < 2.9:
ramdbSchemaVersion = "2.8"



pmcApiServer=systemConfig.mfeSystem["dbPrimaryServer"]
pmcApiPort="8080"

defaultSuffix =  "%s%05d" % ( os.environ["USER"], systemConfig.tcpPortOffset)
mm1RetrievalMmscPort =   systemConfig.tcpPortOffset + 27

#defaultFromAddr = "00353100000@adaptivemobile.com"
#defaultFromAddr = "xxx00353100000@xxxadaptivemobile.com"
defaultFromAddr = "mfmdevine@gmail.com"
defaultToAddr = "mark.devine@adaptivemobile.com"
defaultSubject = "default subject"
defaultMessage = "This is a default message body.\r\n"

mm1AddressType = "/TYPE=PLMN"
mm1AddressDomain = "vodacom.com"
mm1AddressSuffix = mm1AddressType 

#defaultMm1FromAddrBase = "00353871000000"
defaultMm1FromAddrBase = "+353871000000"
defaultMm1ToAddrBase = "+353871111222"
#defaultMm1FromAddrBase = "00353871000000"
#defaultMm1ToAddrBase = "00353871111222"
defaultMm4FromAddrBase = "+353870000000@o2.ie"
defaultMm4ToAddrBase = "+353871111222@02.ie"
defaultMm1FromAddr = defaultMm1FromAddrBase + mm1AddressType
defaultMm1ToAddr = defaultMm1ToAddrBase + mm1AddressType
defaultMm4FromAddr = defaultMm4FromAddrBase + mm1AddressType
defaultMm4ToAddr = defaultMm4ToAddrBase + mm1AddressType
defaultMm1TransactionId = "MmfMessageId"

removedImageString = "Image removed"
removedAttachmentString = "Attachment removed"

# ACTION: Add the following groups and subscribers. When adding subscribers to the 
# protal only enter the subscriber number eg "+353870000001" and
# not the mm1AddressSuffix part

defaultGroupName = "default_%s" % defaultSuffix

# ACTION: need to create a group called frameworkAlwaysEmailNotifcation
# with a filter of type MMS Notification with method of email to
# an email address of always.notificatio@framework.com and assign
# a subscriber with MSISDN of +353870000001 to the group


alwaysNotificationToEmailAddress = "always.notification@framework.com"
# ACTION: need to create a group called frameworkAlwaysSmsNotifcation
# with a filter of type MMS Notification with method of sms to
# an phone address of +353870001001 and assign
# a subscriber with MSISDN of +353870000002 to the group

alwaysNotificationToSmsAddress = "353870001001"

# ACTION: need to create a group called frameworkMmsMimeAll
# with a filter of type MMS MIME Filter for all attachement types
# and the following subsciber

msisdnInternationalPrefix = "+"
prefixLen = len(msisdnInternationalPrefix)

mimeAllSubscribers = ["%s%s%s0000002" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrMimeFilterAllTypes = "00"+mimeAllSubscribers[0][prefixLen:]+mm1AddressType

mimeApplicationReceiveSubscribers = ["%s%s%s0000003" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrMimeFilterReceiveSubscribers = "00"+mimeApplicationReceiveSubscribers[0][prefixLen:]+mm1AddressType

mimeApplicationSentSubscribers = ["%s%s%s0000004" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrMimeFilterSentSubscribers = "00"+mimeApplicationSentSubscribers[0][prefixLen:]+mm1AddressType

textAnalysisSubscribers = ["%s%s%s0000005" % ( msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrTextAnalysis = "00"+textAnalysisSubscribers[0][prefixLen:]+mm1AddressType

textAnalysisEmailNotificationSubscribers = ["%s%s%s0000007" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrTextAnalysisEmailNotification = "00"+textAnalysisEmailNotificationSubscribers[0][prefixLen:]+mm1AddressType

NotificationEmailAlways = ["%s%s%s0000008" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrAlwaysEmailNotification = "00"+NotificationEmailAlways[0][prefixLen:]+mm1AddressType

antiSpamSubscribers = ["%s%s%s0000020" % ( msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultAntiSpamSubscriber = "00"+antiSpamSubscribers[0][prefixLen:]+mm1AddressType

#
Blacklist = ["%s%s%s0000009" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrBlacklist = "00"+Blacklist[0][prefixLen:]+mm1AddressType
blacklistNotification = ["%s%s%s0000021" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrBlacklistNotification = "00"+blacklistNotification[0][prefixLen:]+mm1AddressType
blacklistSenderAddress = ["%s%s%s0000010" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrBlacklistSender =  "00"+blacklistSenderAddress[0][prefixLen:]+mm1AddressType
blacklistReceiverAddress = ["%s%s%s0000011" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrBlacklistReceiver =  "00"+blacklistReceiverAddress[0][prefixLen:]+mm1AddressType

smsServiceBlacklist = ["%s%s%s0000009" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
smsServiceDefaultMm1AddrBlacklist = "00"+smsServiceBlacklist[0][prefixLen:]+mm1AddressType
smsServiceBlacklistAddress = ["%s%s%s0000010" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
smsServiceDefaultMm1AddrBlacklistSender =  "00"+smsServiceBlacklistAddress[0][prefixLen:]+mm1AddressType

WalledGarden = ["%s%s%s0000012" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWalledGarden = "00"+WalledGarden[0][prefixLen:]+mm1AddressType
WalledGardenSenderAddress = ["%s%s%s0000013" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWalledGardenSender =  "00"+WalledGardenSenderAddress[0][prefixLen:]+mm1AddressType
WalledGardenReceiverAddress = ["%s%s%s0000014" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWalledGardenReceiver =  "00"+WalledGardenReceiverAddress[0][prefixLen:]+mm1AddressType

Whitelist = ["%s%s%s0000015" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWhitelist = "00"+Whitelist[0][prefixLen:]+mm1AddressType
whitelistSenderAddress = ["%s%s%s0000016" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWhitelistSender =  "00"+whitelistSenderAddress[0][prefixLen:]+mm1AddressType
whitelistReceiverAddress = ["%s%s%s0000017" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWhitelistReceiver =  "00"+whitelistReceiverAddress[0][prefixLen:]+mm1AddressType

BlacklistWhitelist = ["%s%s%s0000018" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrBlacklistWhitelist = "00"+BlacklistWhitelist[0][prefixLen:]+mm1AddressType
WhitelistBlacklist = ["%s%s%s0000019" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrWhitelistBlacklist = "00"+WhitelistBlacklist[0][prefixLen:]+mm1AddressType

NotificationSMSAlways = ["%s%s%s0001001" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrAlwaysSmsNotification = "00"+NotificationSMSAlways[0][prefixLen:]+mm1AddressType
NotificationSMSMSISDN = "%s%s%s3456789" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)

ImageSignature = ["%s%s%s0000021" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1ImageSignature = "00"+ImageSignature[0][prefixLen:]+mm1AddressType

AdaptiveSpam = ["%s%s%s0000022" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AdaptiveSpam = "00"+AdaptiveSpam[0][prefixLen:]+mm1AddressType

textAnalysisEmailDuplicateSubscribers = ["%s%s%s8092000" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
textAnalysisDictSubscribers = ["%s%s%s8092222" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
textAnalysisMultiDictSubscribers = ["%s%s%s0000023" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
textAnalysisArabicDictSubscribers = ["%s%s%s0000024" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
textAnalysisUtf8DictSubscriber = "%s%s%s0000040" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
starter="%s%s%s" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
textAnalysisUtf8ZWJDictSubscribers = ["%s0000038" % starter, "%s0000039" % starter]
antiVirusGroupSubscriber = "%s%s%s0000025" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
Greylist = ["%s%s%s0000026" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrGreylist = "00"+Greylist[0][prefixLen:]+mm1AddressType
greylistedAddress = ["%s%s%s0000027" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
defaultMm1AddrGreylisted =  "00"+greylistedAddress[0][prefixLen:]+mm1AddressType
mmsServiceBlacklistGroupSubscriber = "%s%s%s0000028" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
mm3SpamSubscriber = "%s%s%s0000028" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
ImageAnalysis = ["%s%s%s0000029" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
mm7TrafficAnalysisSubscriber = "%s%s%s0000030" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
defaultMm1ImageAnalysis = "00"+ImageAnalysis[0][prefixLen:]+mm1AddressType

numberBlacklistSubscriber="%s%s%s0000031" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
numberBlacklistTo=numberBlacklistSubscriber[prefixLen:]+mm1AddressType
numberBlacklisted=["%s%s%s0000032" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix), "%s%s%s0000033" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)]
numberBlacklistFrom=numberBlacklisted[0][prefixLen:]+mm1AddressType
numberBlacklistServices=["SMS","VOICE","MMS"]
mmsServiceRestrictionGroupSubscriber = "%s%s%s0000033" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
mmsServiceRestrictionTo=mmsServiceRestrictionGroupSubscriber[prefixLen:]+mm1AddressType

textAnalysisPhraseLargeDictSubscriber = "%s%s%s0000035" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
textAnalysisLargeDictSubscriber = "%s%s%s0000036" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)

#textAnalysisPhraseSubscriber = "%s%s%s0000050" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)

# Tokenisation Subscribers from 50 to 58
tokenisationSubscriber = 50
tokenisationSubscribers = []
for i in range(8):
    subscriber = "%s%s%s00000%s" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix, tokenisationSubscriber + i)
    tokenisationSubscribers.append(subscriber)
    
    
#textAnalysisArabicPhraseSubscriber = "%s%s%s0000034" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)

googleSafeBrowsingSubscriber = "%s%s%s0000037" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)

attprefix="%s%s%s" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix)
AttachmentSignature = []
for x in range(16):
    subMsisdn=100+x
    AttachmentSignature.append(attprefix+"0000"+str(subMsisdn))

# URL BLACK LIST Subscribers from 41 to 48
urlBlacklistSubscriber = 41
urlBlacklistedSubscribers = []
for i in range(7):
    subscriber = "%s%s%s00000%s" % (msisdnInternationalPrefix, intlPrefix, operatorPrefix, urlBlacklistSubscriber + i)
    urlBlacklistedSubscribers.append(subscriber)

urlBlacklistSenderAddr = "sender@urlblacklist.com"
urlBlacklistReceiverAddr = "receiver@urlblacklist.com"

mm3SpamSenderAddress="user@mm3spammer1.com"

# ACTION: need to create a group called frameworkMmsMimeApplication
# with a filter of type MMS MIME Filter for only the application type
# and the following subsciber
defaultMm1AddrMimeFilterApplicationType = "+353870000004" + mm1AddressSuffix


# ACTION: need to create a group called frameworkMmsTextAnalysis
# with a filter of type MMS Text Analysis and the following subsciber

# ACTION: need to create a group called frameworkMmsDuplicateModify
# with a filter of type duplicate and the following subsciber with
# the filtering criteria of email on block/modify and the following
# email address. Also add a image analysis filter to the group
defaultMm1DuplicateEmailModify = "+353870000006" + mm1AddressSuffix
modifyDuplicateEmailAddress = "mms.duplicate.modify@framework.com"
defaultMm1DuplicateFromAddress = '''"XYZ Customer Care" <noreply@xyz.com.sa>'''

# ACTION: need to create a group called frameworkMmsDuplicate
# with a filter of type duplicate and the following subsciber with
# the filtering criteria of email on always and the following
# email address. 
defaultMm1DuplicateEmailAlways = "+353870000007" + mm1AddressSuffix
alwaysDuplicateEmailAddress = "mms.duplicate.always@framework.com"

configStorageDir = "/tmp/mfeConfig" + os.environ["USER"]

if not os.path.isdir(configStorageDir):
   (err_out, stdin) = popen2.popen4("mkdir " + configStorageDir)

defaultSmtpCharset = "ISO-8859-1"
defaultSmtpMimeVersion = "1.0"

# ACTION: update the etc/mm3SmtpDomain.conf as per the mm3SmtpDomain.conf file
# in the configFiles directory
blackListDomain = "bad0001.com"
blacklistDomainExceptionAddress = "good0001@bad0001.com"
blackListAddress = "bad0001@good0001.com"

smppNotificationEmailAddress = "user1@good0001.com"

profileENTextAnalysis = "profileENTextAnalysis"
profileEDTextAnalysis = "profileEDTextAnalysis"
profileDictTextAnalysis = "profileDictTextAnalysisAscii"
dictTextAnalysis = "dictTextAnalysisAscii"
profileDictTextAnalysisArabic = "profileDictTextAnalysisArabic"
dictTextAnalysisArabic = "dictTextAnalysisArabic"
dictMultipleTextAnalysis = "dictMultipleTextAnalysis"
profileEmailDuplicateAlways = "profileEmailDuplicateAlways"
EmailDuplicateAlwaysSubscribers = ["0868093000", "+353868093000", "353868093000"]
profileMimeImageSent = "profileMimeImageSent"
profileMimeImageReceive = "profileMimeImageRecieve"
profileNotificationEmailAlways = "profileNotificationEmailAlways"
profileMimeImageSent = "profileMimeImageSent"
profileMimeImageReceive = "profileMimeImageRecieve"
profileNotificationSMSAlways = "profileNotificationSMSAlways1"
profileNotificationEmailAlways = "profileNotificationEmailAlways"
profileAVMcAfee = "profileAVMcAfee"
profileTextAnalysis = "profileTextAnalysis"
profileWalledGarden = "profileWalledGarden"
profileBlacklist = "profileBlacklist"
profileGreylist = "profileGreylist"
autoGreylist = "AutoGreyList"
profileBlacklistNotification = "profileBlacklistNotification"
profileWhitelist = "profileWhitelist"
profileRootWhitelist = "profileWhitelist"
profileAntiSpam = "profileAntiSpam"
profileMm3AntiSpam = "profileMm3AntiSpam"
profileSMSServiceBlacklist = "profileSMSServiceBlacklist"
alwaysEmailNotificationGroupName = "alwaysEmailNotifcation"
defaultGroupVodacom = "profileDefaultGroupVodacom"
spamText1 = "spamText1"

notificationAlwaysEmailAddress = "default.notification.always.email.address@default.notification.domain.com"
defaultDictName = "Default Text Analysis Dictionary"
defaultDictContent = "sugar\r\naaaaa\r\naaaaab\r\naaaaa\r\naaaaad\r\naaaaae\r\naaaaaf\r\n"

profileMimeAll = "profileMimeAll"
profileMimeApplicationReceive = "profileMimeApplicationReceive"
profileMimeApplicationSent = "profileMimeApplicationSent"

mimeImageSentSubscribers =    [intlPrefix + operatorPrefix + "0000000"]
mimeImageReceiveSubscribers = [intlPrefix + operatorPrefix + "0000001"]


try:
   testFileRootDir = os.environ["MFE_FRAMEWORK_HOME"]
except Exception,e:
   #testFileRootDir = "/home/colm/mmf_rhel4_test_tool_2_4_0_3/work2/"
   testFileRootDir = ""

# ACTION: add the following file's signature to MFE using mmf_Cli.sh
blockedImage = testFileRootDir + "testFiles/images/blocked/050/Thailand.jpg"
blockedImageBlackAndWhite = testFileRootDir + "testFiles/images/blocked/050/ThailandBlackAndWhite.jpg"
blockedImageCropped = testFileRootDir + "testFiles/images/blocked/050/ThailandCropped.jpg"
blockedImageFlipped = testFileRootDir + "testFiles/images/blocked/050/ThailandFlipped.jpg"
blockedImageNegative = testFileRootDir + "testFiles/images/blocked/050/ThailandNegative.jpg"
blockedImageR90 = testFileRootDir + "testFiles/images/blocked/050/ThailandR90.jpg"

imageDir1000 = "/home/nightlytesterlinux/images"


cleanText = testFileRootDir + "testFiles/texts/clean/001/a.txt"
blockedText = testFileRootDir + "testFiles/texts/blocked/003/expletive.txt"
cleanImageType = "image/jpeg"
cleanImage = testFileRootDir + "testFiles/images/clean/011/Bod.jpg"
blockedApplication = testFileRootDir + "testFiles/applications/clean/100/notepad.exe"
cleanApplication = testFileRootDir + "testFiles/applications/clean/050/twunk_16.exe"
blockedApplication1 = testFileRootDir + "testFiles/applications/clean/100/SmCfg.exe"
cleanVideo = testFileRootDir + "testFiles/videos/050/license2.mpg"
blockedVideo = testFileRootDir + "testFiles/videos/050/license.mpg"
cleanAudio = testFileRootDir + "testFiles/audios/100/license2.MP3"
blockedAudio = testFileRootDir + "testFiles/audios/050/spacemusic.au"
cleanAudioAu = testFileRootDir + "testFiles/audios/050/gong.au"
cleanAudioMP3 = testFileRootDir + "testFiles/audios/100/license2.MP3"

cleanImage1 =  testFileRootDir + "testFiles/images/clean/020/pic1.jpg"
cleanImage2 =  testFileRootDir + "testFiles/images/clean/020/pic2.jpg"
cleanImage3 =  testFileRootDir + "testFiles/images/clean/020/pic3.jpg"
cleanImage4 =  testFileRootDir + "testFiles/images/clean/020/pic4.jpg"

blockedImage1 = testFileRootDir + "testFiles/images/blocked/001/pic1.gif"
blockedImage2 = testFileRootDir + "testFiles/images/blocked/001/pic2.gif"
blockedImage3 = testFileRootDir + "testFiles/images/blocked/001/pic3.gif"
blockedImage4 = testFileRootDir + "testFiles/images/blocked/001/pic4.gif"
blockedImage5 = testFileRootDir + "testFiles/images/blocked/001/pic5.gif"
blockedImage1Small = testFileRootDir + "testFiles/images/blocked/001/pic1small.gif"

IAImage0 = testFileRootDir + "testFiles/images/imageAnalysisJpg/fortiumRate0cartoon.jpg"
IAImage14 = testFileRootDir + "testFiles/images/imageAnalysisJpg/fortiumRate14baby.jpg"
IAImage18 = testFileRootDir + "testFiles/images/imageAnalysisJpg/fortiumRate18beachGirl.jpg"
IAImage27 = testFileRootDir + "testFiles/images/imageAnalysisJpg/fortiumRate27porn.jpg"

#virusApplication = testFileRootDir + "testFiles/applications/blocked/300/test01.tar.gz"
#virusApplication = testFileRootDir + "testFiles/viruses/eicar.rar"
#virusApplication = testFileRootDir + "testFiles/viruses/eicar.com"
#virusApplication = testFileRootDir + "testFiles/viruses/eicar.rar"
#virusApplication = testFileRootDir + "testFiles/viruses/eicar.com"
virusApplication = testFileRootDir + "testFiles/applications/blocked/300/test01.tar.gz"
virusApplicationSophos = testFileRootDir + "testFiles/viruses/eicar.com"
virusApplicationSophosZip = "%s.zip" % virusApplicationSophos
virusTextFile = testFileRootDir + "testFiles/viruses/eicar.txt"

expletiveText50 = testFileRootDir + "testFiles/texts/blocked/050/expletive.txt"
expletiveText03_1 = testFileRootDir + "testFiles/texts/blocked/003/expletive.txt"
expletiveText03_2 = testFileRootDir + "testFiles/texts/blocked/003/expletive2.txt"
expletiveText03_3 = testFileRootDir + "testFiles/texts/blocked/003/expletive3.txt"
expletiveText03_4 = testFileRootDir + "testFiles/texts/blocked/003/expletive4.txt"
expletiveText03_5 = testFileRootDir + "testFiles/texts/blocked/003/expletive5.txt"
expletiveText03_7 = testFileRootDir + "testFiles/texts/blocked/003/expletive7.txt"

expletiveEnglishPhrase = testFileRootDir + "testFiles/texts/blocked/003/expletivePhrase.txt"
expectedEnglishPhrase = testFileRootDir + "testFiles/texts/expected/tokenisationOn.txt"
expectedTokenisationOff = testFileRootDir + "testFiles/texts/expected/tokenisationOff.txt"

expletiveArabicPhrase = testFileRootDir + "testFiles/texts/blocked/003/expletiveArabicPhrase.txt"
expectedArabicPhrase = testFileRootDir + "testFiles/texts/expected/expletiveArabicPhrase.txt"

# Tokenisation Testing
tokenisation_shit = testFileRootDir + "testFiles/texts/blocked/003/tokenisation_shit.txt"
tokenisation_sugar = testFileRootDir + "testFiles/texts/blocked/003/tokenisation_sugar.txt"
tokenisation_bitch = testFileRootDir + "testFiles/texts/blocked/003/tokenisation_bitch.txt"
tokenisation_viagra = testFileRootDir + "testFiles/texts/blocked/003/tokenisation_viagra.txt"
tokenisation_blaster = testFileRootDir + "testFiles/texts/blocked/003/tokenisation_blaster.txt"
tokenisation_bugzilla = testFileRootDir + "testFiles/texts/blocked/003/tokenisation_bugzilla.txt"


expletiveTextArabic = testFileRootDir + "testFiles/texts/blocked/003/expletiveArabic.txt"
expletiveText100 = testFileRootDir + "testFiles/texts/blocked/100/rfc1274.txt"
#expletiveWord = "whore"
expletiveWord = "sugar"
persianFile = testFileRootDir + "testFiles/texts/blocked/003/persian.txt"
persianZWNJFile = testFileRootDir + "testFiles/texts/blocked/003/persian_zwnj.txt"
persianNonZWNJFile = testFileRootDir + "testFiles/texts/blocked/003/persian_nozwnj.txt"


oneWordFile = testFileRootDir + "testFiles/texts/clean/001/one.txt"
twoWordFile = testFileRootDir + "testFiles/texts/clean/001/two.txt"
threeWordFile = testFileRootDir + "testFiles/texts/clean/001/three.txt"
allWordFile = testFileRootDir + "testFiles/texts/clean/001/all.txt"

smsSpamText_1 = testFileRootDir + "testFiles/texts/spam/sms_spam1.txt"
smsSpamText_2 = testFileRootDir + "testFiles/texts/spam/sms_spam2.txt"
mmsSpamText1 = testFileRootDir + "testFiles/texts/spam/sms_spam1.txt"
mmsSpamText2 = testFileRootDir + "testFiles/texts/spam/sms_spam2.txt"
mmsSpamTextLarge = testFileRootDir + "testFiles/texts/spam/1.txt"
mm3SpamhausFromAddress = "00353882222222@mm3blacklist1.com"

compressedFileZ = testFileRootDir + "testFiles/compressed/nn.Z"
compressedFileZip = testFileRootDir + "testFiles/compressed/testResultsReport_colm.zip"
compressedFileZipNested = testFileRootDir + "testFiles/compressed/testResultsReport_jamesm.zip"
compressedFileGzip = testFileRootDir + "testFiles/compressed/longfile.txt.gz"

sampleSpamEmailDir = testFileRootDir + "testFiles/emails/spam_eml"
sampleNonSpamEmailDir = testFileRootDir + "testFiles/emails/clean_eml"
performance30kSpamEmailDir = testFileRootDir + "testFiles/emails/performance_30k_spam"
performance30kCleanEmailDir = testFileRootDir + "testFiles/emails/performance_30k_clean"
performance30wordsTextFileMM3 = testFileRootDir + "testFiles/mm3/performance_100k/30words.txt"
performance100kEmailMM3Dir = testFileRootDir + "testFiles/mm3/performance_100k/attachment_100k"
performance100kMM4Dir = testFileRootDir + "testFiles/mm4/performance_100k/attachment_100k"
performance30wordsTextFileMM7 = testFileRootDir + "testFiles/mm3/performance_100k/30words.txt"
performance100kMM7Dir = testFileRootDir + "testFiles/mm3/performance_100k/attachment_100k"
performance70charSMSDir = testFileRootDir + "testFiles/sms/performance_70char"
smsTestToolInstallationDir = "/opt/ams/sms-test-tool"
sampleSpamMessageFile = "%s/%s" % (sampleSpamEmailDir,"iportSpam212.eml")
sampleSpamMessageFile = testFileRootDir + "testFiles/emails/spam_eml/gtube.eml"
fh =  open(sampleSpamMessageFile)
sampleSpamMessage = fh.read()

badURL = testFileRootDir + "testFiles/texts/blocked/050/badURL.txt"

# URL BLACK LIST Testing
blacklistedURL = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL.txt"
blacklistedURL1 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL1.txt"
blacklistedURL2 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL2.txt"
blacklistedURL3 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL3.txt"
blacklistedURL4 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL4.txt"
blacklistedURL5 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL5.txt"
blacklistedURL6 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL6.txt"
blacklistedURL7 = testFileRootDir + "testFiles/texts/blocked/050/blacklistedURL7.txt"

expectedBlacklistedURL = testFileRootDir + "testFiles/texts/expected/blacklistedURL.txt"
expectedBlacklistedURL1 = testFileRootDir + "testFiles/texts/expected/blacklistedURL1.txt"
expectedBlacklistedURL2 = testFileRootDir + "testFiles/texts/expected/blacklistedURL2.txt"
expectedBlacklistedURL3 = testFileRootDir + "testFiles/texts/expected/blacklistedURL3.txt"
expectedBlacklistedURL4 = testFileRootDir + "testFiles/texts/expected/blacklistedURL4.txt"
expectedBlacklistedURL5 = testFileRootDir + "testFiles/texts/expected/blacklistedURL5.txt"
expectedBlacklistedURL6 = testFileRootDir + "testFiles/texts/expected/blacklistedURL6.txt"
expectedBlacklistedURL7 = testFileRootDir + "testFiles/texts/expected/blacklistedURL7.txt"


mm1StcCaptureFileDir = "/home/colm/captures/stc/mm1/switchover_1.cap.files"
mm1StcCaptureFileDir = "/home/colm/captures/stc/mm1/switchover_1.cap.files"

defaultSmppBindTime = 10   # allow 10 seconds for MFE to bind to us

# ACTION: set the following to the directory where you want log files to go
testLogsRootDirectory = "/tmp/mfeTestLogs_%s" % os.environ["USER"]
if not os.path.isdir(testLogsRootDirectory):
   (err_out, stdin) = popen2.popen4("mkdir " + testLogsRootDirectory)


mfeFileLogging = True

#ACTION: check that these are the domains and headers setup in etc/Services2Profiles.txt
UnifiedMessagingDomain = "vodafone.net"
UnifiedMessagingDomain2 = "vodafone1.net"
MMSOutDomain = "mmsbe3.ve.vodafone.co.uk"
MMSInDomain = "mms.mnc015.mcc234.gprs"
ConsumerPushHeader = "X-AMS-ServiceId"
#ACTION: check that these groups are setup in the database
profileUnifiedMessaging = "profileUnifiedMessaging"
profileMmsOutbound = "profileMmsOutbound"
profileMmsInbound = "profileMmsInbound"
profileConsumerPush = "profileConsumerPush"

# API variables
policyID=1
userDets={'msisdn' : '+3538570099999', 'email' : 'markdevine@go.com', 'password' : '', 'timezone' : 1}
subUserDets = {'adminMSISDN' : '+3538570099999', 'subscriberMSISDN' : '+3538570099999', 'policyID' : policyID, 'firstName' : 'Mark', 'lastName' : 'Devine'}
timePlanName='Mark_test_time'
tpList=['111111111111111111111111',
        '111111111111111111111111',
        '111111111111111111111111',
        '111111111111111111111111',
        '111111111111111111111111',
        '000000000001111111111100',
        '000000000001111111111100']
divertNumber='+3531111112'
forwardNumber='+3538570099992'
blNumber="+353852222222"
wlNumber="+353853333333"
wgNumber="+353854444444"
def srNumber(number):
    return number[1:]+mm1AddressType

#ACTION: check the filterOutcomeAction value in pcfconfig.xml and set the following variable accordingly
BLOCKALL = 0
BLOCKAFFECTED = 1
MODIFY = 2
filterOutcomeAction = BLOCKALL

# this is the SMTP error the PFE shall send back when a message is to be rejected 
rejectError = 554   

# default amount of time in seconds to wait for PFE to respond to an email request
defaultSmtpClientTimeout = 100

# Length of time in seconds to wait before Mfe rereads dynamically updated config files
defaultDynamicFileUpdateTime = 10


defaultLoggingFormat = '%(asctime)s %(levelname)s %(pathname)s:%(lineno)d thread[%(thread)d] [[[%(message)s]]]'

textTrackingEnglishWord = "textTrackingWord"
textTrackingFile = testFileRootDir + "testFiles/texts/clean/001/textTrackingSample.txt"

#ACTION: create duplicate server with default external code for quarantine

smppUsername = "mySmppUsername"
smppPassword = "mySmppPassword"
scenarioDefaultTestDuration = 300
scenarioDefaultEmailMessageRate = 60
scenarioDefaultMm1MessageRate = 15
scenarioDefaultMm7MessageRate = 15
scenarioBlacklistSize = 10
scenarioMessageDelay = 0.1

#LDAP Section
ldapDefaultDirectory= testFileRootDir + "site-packages/aqa/mfe/ldap/"
#only for intel-test
ldapInstallationDirectory = "/opt/ams/aqa/openldap"
ldifFilename = ldapDefaultDirectory+"LDAP_Users.ldif"

gtpDefaultPort = 3386

ss7Settings= {
         "srcIp":"10.10.10.39",
         "srcPort":2907,
         "destIp":systemConfig.tprMachine,
         "destPort":2908,
         "smscPc":1000,
         "hlrPc":1001,
         "mscPc":1002,
         "specificRoutingContext":0,
         "specificTprPc":5352,   # TPR PC=5352   TPR virtual PC = 5354
         "virtualRoutingContext":1,
         "virtualTprPc":5354,   # TPR PC=5352   TPR virtual PC = 5354
         "moAddr":"491722000000",
         "mscGT" :"491720000021",
         "smscGT":"491720000011",
         "hlrGT" :"491722000001",
         "tprGT" :"491720499014",
         "socketTimeout":10,
         "useSpecificPc":True
   }

ss7Settings= {
         "srcIp":"10.10.10.39",
         "srcPort":2906,
         "destIp":systemConfig.tprMachine,
         "destPort":2906,
         "smscPc":1000,
         "hlrPc":1001,
         "mscPc":1002,
         "specificRoutingContext":0,
         "specificTprPc":5352,   # TPR PC=5352   TPR virtual PC = 5354
         "virtualRoutingContext":1,
         "virtualTprPc":5354,   # TPR PC=5352   TPR virtual PC = 5354
         "moAddr":"491722000000",
         "mscGT" :"491720000021",
         "smscGT":"491720000011",
         "hlrGT" :"491722000001",
         "tprGT" :"491720499014",
         "socketTimeout":10,
         "useSpecificPc":True
   }

if __name__ == '__main__':
   print "details of mfeSystem are:\n%s" % systemConfig.mfeSystem

