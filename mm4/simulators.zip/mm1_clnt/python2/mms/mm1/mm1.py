import socket
import binascii
import os, sys, time
import string

try:
   import systemConfig
   defaultMmscIp = systemConfig.mfeSystem["ip"]
   defaultMmscPort = systemConfig.mfeSystem["mmscPort"]
except:
   defaultMmscIp = "127.0.0.1"
   defaultMmscPort = 8080

RESPONSE_STATUS_OK = '%c' % 0x80
RESPONSE_STATUS_UNSPECIFIED = '%c' % 0x81
RESPONSE_STATUS_SERVICE_DENIED = '%c' % 0x82
RESPONSE_STATUS_CORRUPT = '%c' % 0x83
RESPONSE_STATUS_SENDING_ADDRESS_UNRESOLVED = '%c' % 0x84
RESPONSE_STATUS_NETWORK_PROBLEM = '%c' % 0x86

def encodeLength(length):
   if length < 0x80:
      enocdedLen = chr(length)
   elif length < 0x80FF:
      enocdedLen = '%c%c' % (
                ((length >> 7) & 0xFF) | 0x80,
                length & 0x7F
                )
   elif length < 0x80FFFF:
      enocdedLen = '%c%c%c' % (
                ((length >> 14) & 0xFF) | 0x80,
                ((length >> 7) & 0xFF) | 0x80,
                length & 0x7F
                )
   elif length < 0x80FFFFFF:
      enocdedLen = '%c%c%c%c' % (
                ((length >> 21) & 0xFF) | 0x80,
                ((length >> 14) & 0xFF) | 0x80,
                ((length >> 7) & 0xFF) | 0x80,
                length & 0x7F
                )
   else:
      raise Exception, "unable to encode length  hex=[%x]" % (length)
#  print "ecoded len = [%s]" % binascii.b2a_hex(enocdedLen)
   return enocdedLen

def encodeValueLength(length):

   #Section 8.4.2.2 of the WSP spec defines how "Value-length" is encoded. Basically, if the length is between 0 and 30 bytes, then it is encoded as a "short-length" value where the length is encoded as a single byte. If the length is longer than 30 bytes, then it is encoded as length-quote (31, or 0x1F) followed by a uintvar encoding of the length.

   #In the example above, 1F 21 is a "value-length" encoding of 0x21 (33 decimal) indicating that the "media-type" encoding that follows is 33 bytes in length. 
   if length > 30:
      encodedValLen = binascii.a2b_hex("1f%02X" % length)
   else:
      encodedValLen =  binascii.a2b_hex("%02X" % length)
   return encodedValLen


def createHttpMm1Post(postContent = "", hostHeader = "%s:%d" % (defaultMmscIp, defaultMmscPort), msisdnHeader = None, msisdnFrom = None, userAgent = """Nokia6230/2.1 (05.24) Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Link/6.3.1.13.0""", userProfile = '"http://nds1.nds.nokia.com/uaprof/NN70-1r100-VF2G.xml"'):
   if msisdnHeader != None:
      msisdnHeaderValue = msisdnHeader + ": " + msisdnFrom + "\r\n"
   else:
      msisdnHeaderValue = ""
   if userAgent == None:
      userAgentHeaderLine = ""
   else:
      userAgentHeaderLine = "User-Agent: " + userAgent + "\r\n"
   if userProfile == None:
      userProfileLine = ""
   else:
      userProfileLine = "x-wap-profile: " + userProfile + "\r\n"

   httpHeaders = """POST /mms_x.fcgi.sh HTTP/1.1\r\nHost: %s\r\nContent-Length: %d\r\n%sConnection: close\r\nContent-Type: application/vnd.wap.mms-message\r\nX-JINNY-CID: %s\r\nAccept: application/vnd.wap.mms-message\r\nAccept-Encoding: gzip, deflate\r\n%s%sCookie2: $Version="1"\r\n\r\n""" % (hostHeader, len(postContent), msisdnHeaderValue, msisdnFrom, userAgentHeaderLine, userProfileLine)
#  print "http headers = \n%s" % httpHeaders
   message = httpHeaders + postContent
#  print "size of MM1 post is %d" % (len(message))
   if len(message) > 150000:
      print "##################################################################"
      print "WARNING size of MM1 post is greater than MMF default size (150000)"
      print "##################################################################\n"
   return message

def createMSendReq(transactionId = "transid0001",toAddress="9613083302/TYPE=PLMN", toAddressUtf8 = None, toAddresses = [], fromAddress = "00353869000000/TYPE=PLMN", bccAddress = None, bccAddressUtf8 = None, contentType = "application/smil", subject = None, contentStartTag = "<VP34L>", multiPartBody = "", utf8Subject = None, date = None):
   fieldTerminator =  "\x00"
   XMmsMessageTypeMSendReq = binascii.a2b_hex("8C80")
   XMmsTransactionId =  binascii.a2b_hex("98") + transactionId + fieldTerminator
   XMmsVersion = binascii.a2b_hex("8D90")   # 1.0 supported only
   if fromAddress == None:
      From = binascii.a2b_hex("890181")    # default from address supported only
   else:
      fromBase = "\x80" + fromAddress + fieldTerminator
      From = "\x89" + encodeValueLength(len(fromBase)) + fromBase
   if bccAddress != None:
      bcc = "\x81" + bccAddress + fieldTerminator
   else:
      bcc = ""
   if bccAddressUtf8 != None:
      bccBase = "\xea" + bccAddressUtf8 + fieldTerminator
      bcc = "\x81" + encodeValueLength(len(bccBase)) + bccBase
   if subject != None:
      Subject = "\x96" + subject + fieldTerminator
   else:
      Subject = ""
   if utf8Subject != None:
      encodedSubject = "\xea\x7f" + utf8Subject + fieldTerminator
      Subject = "\x96" + encodeValueLength(len(encodedSubject)) + encodedSubject
   XMmsDeliverReport = binascii.a2b_hex("8681")   # delivery report off supported only
   if toAddresses == []:
      toAddresses.append(toAddress)
   To = ""
   for toAddress in toAddresses:
      To += "\x97" + toAddress + fieldTerminator
   if toAddressUtf8 != None:
      encodedTo = "\xea" + toAddressUtf8 + fieldTerminator
      To = "\x97" + encodeValueLength(len(encodedTo)) + encodedTo
#  print "to address To = [%s]" % binascii.b2a_hex(To)
   Timestamp = ""
   if not date:
      Timestamp = "\x85\x04" + binascii.a2b_hex("%02x" % time.time())
#  print "Date: %s" % binascii.b2a_hex(Timestamp)
      
   #contentTypeField = binascii.a2b_hex("1CB389") + contentType + fieldTerminator + binascii.a2b_hex("8A") + contentStartTag + fieldTerminator
   contentTypeTag = "\x84"
   contentTypeWapMultiPart = "\xB3"
   contentTypeField = contentTypeTag + contentTypeWapMultiPart
#  print "contentTypeField = [%s]\n\n" % binascii.b2a_hex(contentTypeField)
#  print " XMmsMessageTypeMSendReq [%s]\n XMmsTransactionId  [%s]\n XMmsVersion  [%s]\n From [%s]\n XMmsDeliverReport [%s]\n To [%s]\n contentTypeField [%s]\n " % (binascii.b2a_hex(XMmsMessageTypeMSendReq),binascii.b2a_hex(XMmsTransactionId),binascii.b2a_hex(XMmsVersion),binascii.b2a_hex(From),binascii.b2a_hex(XMmsDeliverReport),binascii.b2a_hex(To),binascii.b2a_hex(contentTypeField))
   mSendReqHeaders = XMmsMessageTypeMSendReq + XMmsTransactionId + XMmsVersion + From + XMmsDeliverReport + To + bcc + Timestamp + Subject + contentTypeField
#  print "mSendReqHeaders = [%s]" % binascii.b2a_hex(mSendReqHeaders)
   mSendReq = mSendReqHeaders + multiPartBody
#  print "full mSendReq = [%s]" % binascii.b2a_hex(mSendReq)
   return mSendReq


def createMultiPartBody(bodyParts = []):
   #numberOfMessageParts = binascii.a2b_hex("%02d"%len(bodyParts))
   numberOfMessageParts = encodeLength(len(bodyParts))
   multiPartBody = numberOfMessageParts
   for bodyPart in bodyParts:
      multiPartBody += bodyPart
   return multiPartBody

def createSinglePart(contentType = """application/smil""",fileName = "p.smil", contentId = "<VP34L>", contentLocationString = "p.smil", content = """<smil> </smil>"""):
   fieldTerminator =  binascii.a2b_hex("00")
   fileNameTag=  binascii.a2b_hex("86")
   nameTag=  binascii.a2b_hex("85")
   contentIdTag =  binascii.a2b_hex("C0")
   contentLocationTag =  binascii.a2b_hex("8E")
   utf8Charset = binascii.a2b_hex("81EA")

   headerLen = 0 # length of content type + headers
   bodyLen = 0

   contentTypeTag = binascii.a2b_hex("1F")
   contentTypeBody = contentType + fieldTerminator + utf8Charset + fileNameTag + "fileName:" +  fileName + fieldTerminator + nameTag + "name:" +  fileName + fieldTerminator
   #contentTypeLen = binascii.a2b_hex("%02x"%len(contentTypeBody))
   contentTypeLen = encodeLength(len(contentTypeBody))
   contentTypeField = contentTypeTag + contentTypeLen + contentTypeBody
#  print "contentTypeField = [%s]" % (binascii.b2a_hex(contentTypeField))

   contentId = contentIdTag +"\"" + "contentId:" + contentId  + fieldTerminator
   if len(contentLocationString) > 10:
      contentLocationString = contentLocationString[-10:] #  trim everything exxcept the last 10 chars
   contentLocation = contentLocationTag + "cntLo" + contentLocationString + fieldTerminator
   contentDisposition = binascii.a2b_hex("AE%02x8186" % ( 2 + len("cntLo" + contentLocationString + fieldTerminator))) + "cntLo" + contentLocationString + fieldTerminator


#  print "contentId = [%s] contentLocation = [%s] contentDisposition [%s]" % (binascii.b2a_hex(contentId),binascii.b2a_hex(contentLocation),binascii.b2a_hex(contentDisposition))

   headers = contentTypeField + contentId + contentLocation + contentDisposition
   headerLen = encodeLength(len(headers))
   bodyLen = encodeLength(len(content))
#  print "headerLen = [%s] bodyLen = [%s]" % (binascii.b2a_hex(headerLen),binascii.b2a_hex(bodyLen))
#  print "full message part headers = [%s]" % binascii.b2a_hex(headerLen + bodyLen + headers)
   singlePart = headerLen + bodyLen + headers + content
#  print "created single part = [%s]" % (binascii.b2a_hex(singlePart))
   return singlePart

def createMSendConfHttpResponse(transactionId = "transid0001", messageId = "msgId0001", responseStatusValue = RESPONSE_STATUS_OK, responseTextValue = "Response from AQA verion 2.0 MMSC server", messageIdValue = "01234567890123456789"):
   fieldTerminator =  binascii.a2b_hex("00")
   XMmsMessageTypeMSendConf = binascii.a2b_hex("8C81")
   XMmsTransactionId =  binascii.a2b_hex("98") + transactionId + fieldTerminator
   XMmsVersion = binascii.a2b_hex("8D90")   # 1.0 supported only
   responseStatusTag=  '%c' % 0x92
   reponseStatus = responseStatusTag + responseStatusValue
   responseTextTag=  '%c' % 0x93
   reponseText = responseTextTag + responseTextValue + fieldTerminator
   messageIdTag = '%c' % 0x8b
   messageId = messageIdTag + messageIdValue + fieldTerminator
   mSendConf =  XMmsMessageTypeMSendConf + XMmsTransactionId + XMmsVersion + reponseStatus + reponseText + messageId
#  print "generated mSendConf:\n%s" % binascii.b2a_hex(mSendConf)
   httpResponse = "HTTP/1.1 200 OK\r\nContent-Type: application/vnd.wap.mms-message\r\nContent-Length: %d\r\n\r\n" % len(mSendConf) + mSendConf
   return httpResponse

def makeDefaultMessage():
   part1 = createSinglePart()
   contentString = ""
   for i in range (1,3):
     contentString = contentString + "this is line %i" % i
   #part2 = createSinglePart(contentType = "text/plain",fileName = "x.txt", contentLocationString = "/tmp/x.txt", content = contentString)
   part2 = createSinglePart(contentType = "image/jpeg323783278378",fileName = "x.txt", contentLocationString = "/tmp/x.txt", content = contentString)
   bodyParts = [part1,part2]
   for i in range(1,2):
      bodyParts.append(part2)
   multiPart = createMultiPartBody(bodyParts = bodyParts)
   mSendReq = createMSendReq(multiPartBody = multiPart)

   httpMm1 = createHttpMm1Post( postContent = mSendReq)
   return httpMm1

Content_Types={".ai" : "application/postscript",".aif" : "audio/x-aiff",".aifc" : "audio/x-aiff",".aiff" : "audio/x-aiff",
   ".asc" : "text/plain",".au" : "audio/basic",".avi" : "video/x-msvideo",".bcpio" : "application/x-bcpio",".bin" : "application/octet-stream",
   ".bmp" : "image/bmp",".c" : "text/plain",".cc" : "text/plain",".ccad" : "application/clariscad",".cdf" : "application/x-netcdf",
   ".class" : "application/octet-stream", ".com" : "application/octet-stream", ".cpio" : "application/x-cpio",
   ".cpt" : "application/mac-compactpro",".csh" : "application/x-csh",
   ".css" : "text/css",".dcr" : "application/x-director",".dir" : "application/x-director",".dms" : "application/octet-stream",
   ".doc" : "application/msword",".drw" : "application/drafting",".dvi" : "application/x-dvi",".dwg" : "application/acad",
   ".dxf" : "application/dxf",".dxr" : "application/x-director",".eps" : "application/postscript",".etx" : "text/x-setext",
   ".exe" : "application/octet-stream",".ez" : "application/andrew-inset",".f" : "text/plain",".f90" : "text/plain",".fli" : "video/x-fli",
   ".gif" : "image/gif",".gtar" : "application/x-gtar",".gz" : "application/x-gzip",".h" : "text/plain",".hdf" : "application/x-hdf",
   ".hh" : "text/plain",".hqx" : "application/mac-binhex40",".htm" : "text/html",".html" : "text/html",".ice" : "x-conference/x-cooltalk",
   ".ief" : "image/ief",".iges" : "model/iges",".igs" : "model/iges",".ips" : "application/x-ipscript",".ipx" : "application/x-ipix",
   ".jpe" : "image/jpeg",".jpeg" : "image/jpeg",".jpg" : "image/jpeg",".js" : "application/x-javascript",".kar" : "audio/midi",
   ".latex" : "application/x-latex",".lha" : "application/octet-stream",".lsp" : "application/x-lisp",".lzh" : "application/octet-stream",
   ".m" : "text/plain",".man" : "application/x-troff-man",".me" : "application/x-troff-me",".mesh" : "model/mesh",".mid" : "audio/midi",
   ".midi" : "audio/midi",".mif" : "application/vnd.mif",".mime" : "www/mime",".mov" : "video/quicktime",".movie" : "video/x-sgi-movie",
   ".mp2" : "audio/mpeg",".mp3" : "audio/mpeg",".mpe" : "video/mpeg",".mpeg" : "video/mpeg",".mpg" : "video/mpeg",".mpga" : "audio/mpeg",
   ".ms" : "application/x-troff-ms",".msh" : "model/mesh",".nc" : "application/x-netcdf",".oda" : "application/oda",
   ".pbm" : "image/x-portable-bitmap",".pdb" : "chemical/x-pdb",".pdf" : "application/pdf",".pgm" : "image/x-portable-graymap",
   ".pgn" : "application/x-chess-pgn",".png" : "image/png",".pnm" : "image/x-portable-anymap",".pot" : "application/mspowerpoint",
   ".ppm" : "image/x-portable-pixmap",".pps" : "application/mspowerpoint",".ppt" : "application/mspowerpoint",".ppz" : "application/mspowerpoint",
   ".pre" : "application/x-freelance",".prt" : "application/pro_eng",".ps" : "application/postscript",".qt" : "video/quicktime",
   ".ra" : "audio/x-realaudio",".ram" : "audio/x-pn-realaudio",".ras" : "image/cmu-raster",".rgb" : "image/x-rgb",".rm" : "audio/x-pn-realaudio",
   ".roff" : "application/x-troff",".rpm" : "audio/x-pn-realaudio-plugin",".rtf" : "text/rtf",".rtx" : "text/richtext",
   ".scm" : "application/x-lotusscreencam",".set" : "application/set",".sgm" : "text/sgml",".sgml" : "text/sgml",".sh" : "application/x-sh",
   ".shar" : "application/x-shar",".silo" : "model/mesh",".sit" : "application/x-stuffit",".skd" : "application/x-koan",
   ".skm" : "application/x-koan",".skp" : "application/x-koan",".skt" : "application/x-koan",".smi" : "application/smil",
   ".smil" : "application/smil",".snd" : "audio/basic",".sol" : "application/solids",".spl" : "application/x-futuresplash",
   ".src" : "application/x-wais-source",".step" : "application/STEP",".stl" : "application/SLA",".stp" : "application/STEP",
   ".sv4cpio" : "application/x-sv4cpio",".sv4crc" : "application/x-sv4crc",".swf" : "application/x-shockwave-flash",
   ".t" : "application/x-troff",".tar" : "application/x-tar",".tcl" : "application/x-tcl",".tex" : "application/x-tex",
   ".texi" : "application/x-texinfo",".texinfo" : "application/x-texinfo",".tif" : "image/tiff",".tiff" : "image/tiff",
   ".tr" : "application/x-troff",".tsi" : "audio/TSP-audio",".tsp" : "application/dsptype",".tsv" : "text/tab-separated-values",
   ".txt" : "text/plain",".unv" : "application/i-deas",".ustar" : "application/x-ustar",".vcd" : "application/x-cdlink",
   ".vda" : "application/vda",".viv" : "video/vnd.vivo",".vivo" : "video/vnd.vivo",".vrml" : "model/vrml",".wav" : "audio/x-wav",
   ".wrl" : "model/vrml",".xbm" : "image/x-xbitmap",".xlc" : "application/vnd.ms-excel",".xll" : "application/vnd.ms-excel",
   ".xlm" : "application/vnd.ms-excel",".xls" : "application/vnd.ms-excel",".xlw" : "application/vnd.ms-excel",".xml" : "text/xml",
   ".xpm" : "image/x-xpixmap",".xwd" : "image/x-xwindowdump",".xyz" : "chemical/x-pdb",".wbmp" : "image/vnd.wap.wbmp",".wma" : "audio/x-ms-wma",
   ".wml" : "text/vnd.wap.wml",".wmls" : "text/vnd.wap.wmlscript",".zip" : "application/zip",
   ".ogg" : "application/ogg", ".3gp" : "video/3gpp"}
   
   
addressType = "/TYPE=PLMN"

class Message:
   defaultUserAgent = """Nokia6230/2.1 (05.24) Profile/MIDP-2.0 Configuration/CLDC-1.1 UP.Link/6.3.1.13.0"""
   defaultProfile = '"http://nds1.nds.nokia.com/uaprof/NN70-1r100-VF2G.xml"'
   def __init__(self,to="00353871234567/TYPE=PLMN",fromfield="00353871111222/TYPE=PLMN",transaction_id="MmfMessageId",msg_type="m-send-req", subject = None, headerName = None, log = None, userAgent = defaultUserAgent, userProfile = defaultProfile):
      self.log = log

#     if not fromfield.startswith("+"):
#         fromfield = '+' + fromfield
      if not fromfield.endswith(addressType):
          fromfield += addressType
#     if to.startswith('00'):
#         to = to.lstrip('00')
#     if not to.startswith('+'):
#         to = '+' + to    
      if not to.endswith(addressType):
          to += addressType

#     print "fromfield: ", fromfield
#     print "to: ", to
      self.toAddresses = []
      self.setTo(to)
      self.transactionId=transaction_id
      self.fromfield = fromfield
      self.subject = subject
      self.parts = []
      self.bccAddress = None
      self.headerName = headerName
      self.httpMm1 = None
      self.userAgent = userAgent
      self.userProfile = userProfile
   
   def addContentFromFile(self,filename):
      """
      will add the attachment to our message
      """
      file2=os.path.split(filename)[1]
#print "%d - adding content from the following file to our MM1: %s" % (os.getpid(), file2)
      ext=string.lower(os.path.splitext(file2)[1])
      try:
         contentType = Content_Types[ext]
      except KeyError, e:
         contentType = "application/octet-stream"
      
      print "filename: ", filename
      fname = ""
      try:   
          fh = open(filename,"r")
          fname = fh.name
      except IOError, e:
          self.log.debug("Unable to open %s. %d: %s" % (fname, e.args[0], e.args[1]))
          sys.exit(1)
      else:
          fileContent = fh.read()
          fh.close()        
      part = createSinglePart(contentType = contentType, content = fileContent, fileName = file2, contentId = file2, contentLocationString = file2)
      self.parts.append(part)
      self.log.debug("added filename %s content type %s to message" % (filename,contentType))

   def addContent(self,filename, content):
      file2=os.path.split(filename)[1]
      ext=string.lower(os.path.splitext(file2)[1])
      try:
         contentType = Content_Types[ext]
      except KeyError, e:
         contentType = "application/octet-stream"
      part = createSinglePart(contentType = contentType,content = content, fileName = filename, contentId = filename, contentLocationString = filename)
      self.parts.append(part)
      self.log.debug("added filename %s content type %s to message" % (filename,contentType))

   def setTo(self, to):
      #self.log.debug("Adding %s to the message To field" % to)
#     if not to.startswith('+'):
# to = '+' + to
      if not to.endswith(addressType):
          to += addressType
    
      self.toAddresses.append(to)   

   def get(self):
      if self.httpMm1 == None:
         multiPart = createMultiPartBody(bodyParts = self.parts)
         mSendReq = createMSendReq(multiPartBody = multiPart, bccAddress = self.bccAddress, subject = self.subject, toAddresses = self.toAddresses, fromAddress = self.fromfield)
         self.httpMm1 = createHttpMm1Post(postContent = mSendReq, msisdnHeader = self.headerName, msisdnFrom = self.fromfield, userAgent = self.userAgent, userProfile = self.userProfile)
      return self.httpMm1
   def as_string(self):
      return self.get()
   def get_body(self):
      return self.get()
    

class HttpClient:
   def __init__(self, log = None, port = None, ip = None):
      self.log = log
      self.soc = None
      self.port = port
      self.ip = ip
   def cleanUp(self):
      if self.soc != None:
         self.soc.close()
         self.soc = None
   def makeSocket(self, timeout = 10, ip = None, port = None):
      self.cleanUp()
      if self.port == None:
         self.port = port
      if self.ip == None:
         self.ip = ip
      self.log.debug("making HttpClient socket to port %d on %s timeout = %d" % (self.port, self.ip, timeout))
      #self.log.debug("james says timeout is %d" %timeout)
      self.soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

      self.soc.setblocking(1) # set to blocking 
      self.soc.settimeout(timeout)
      self.soc.setsockopt(socket.SOL_SOCKET,socket.SO_SNDBUF,5000000)
      try:
          self.soc.connect((self.ip,self.port))
      except socket.error, e:
          self.log.debug("Cannot connect to %s on %d. %d: %s" % (self.ip, self.port, e.args[0], e.args[1]))
          sys.exit(1) 
      self.timeout = timeout
      
   def execute(self, msg, returnResponse = True, rawMessage = None):
      self.makeSocket()
      if rawMessage == None:
         rawMessage = msg.get()
      else:
         rawMessage = rawMessage
      self.log.debug("sending %d bytes of data" % len(rawMessage))
      sendBufferSize = 1024
      if len(rawMessage) < sendBufferSize:
         sent = self.soc.send(rawMessage)
         assert sent == len(rawMessage), "sent %d bytes message was %d bytes" % ( sent, len(rawMessage))
      else:
         endSend = 0
         for i in xrange(len(rawMessage)/sendBufferSize):
            startSend = i * sendBufferSize
            endSend = (i*sendBufferSize) + sendBufferSize
            sent = self.soc.send(rawMessage[startSend:endSend])
         sent = self.soc.send(rawMessage[endSend:])
      if returnResponse:
         return self.receiveRaw()
     
   def receiveRaw(self):
      self.log.debug("attempting to receive data. Soc timeout is %d" % self.soc.gettimeout())
      response = self.soc.recv(19024)
      self.log.debug("received %d bytes of data" % len(response))
      return response
      

class MM1Client(HttpClient):
   def makeSocket(self, timeout = 10, ip = defaultMmscIp, port = defaultMmscPort):
      HttpClient.makeSocket(self,timeout,ip,port)

if __name__ == '__main__':

   print "sending 0A expecting 0A"
   encodeLength(10)
   print "sending 80 expecting 8100"
   encodeLength(128)  
   print "sending 10a expecting 820a"
   encodeLength(266)  
   print "sending 90ed expecting 82a16d"
   encodeLength(37101)  # 90ED expecting 82a16d
   print "sending 87a5 expecting 828f25"
   encodeLength(34725) 
   print "sending 186a0 expecting 868d20"
   encodeLength(100000)
   print "sending 989680 expecting 84 e2 ad 00"
   encodeLength(10000000)
   encodeLength(1000000000)

   print "concatenated lengths are : %s" % (binascii.b2a_hex( encodeLength(266) +  encodeLength(266) +  encodeLength(266)))
 
   part1 = createSinglePart()
   contentString = ""
   for i in range (1,2):
     contentString = contentString + "this is line %i\r\n" % i
   #part2 = createSinglePart(contentType = "text/plain",fileName = "x.txt", contentLocationString = "/tmp/x.txt", content = contentString)
   part2 = createSinglePart(contentType = "image/jpeg323783278378",fileName = "x.txt", contentLocationString = "/tmp/x.txt", content = contentString)
   bodyParts = [part1,part2]
   for i in range(1,2):
      bodyParts.append(part2)
   multiPart = createMultiPartBody(bodyParts = bodyParts)
   mSendReq = createMSendReq(multiPartBody = multiPart)

   httpMm1 = createHttpMm1Post( postContent = mSendReq)

   import time
   msgNum = 0
   while (1):
      socketNumber = 1
      s = []
      for i in range(0,socketNumber):
         s.append( socket.socket(socket.AF_INET, socket.SOCK_STREAM))
         #s.connect(("10.10.10.39", 8000))
         s[i].connect(("193.100.200.72", 8072))
         print "httpMm1 size = %d" % len(httpMm1)
         s[i].send(httpMm1)
         msgNum += 1
         print "msg number %d" % msgNum
      time.sleep(0.1)
      for i in range(0,socketNumber):
         s[i].close()
      break
      #response = s.recv(1024)
      #print "received response [%s]" % response
   
