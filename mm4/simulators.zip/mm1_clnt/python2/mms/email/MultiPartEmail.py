import os, string, smtplib, email, email.Encoders, email.MIMENonMultipart, email.MIMEMultipart, time, datetime, email.MIMEText

defaultToAddr = ''
defaultFromAddr = ''

Content_Types= {".ai" : "application/postscript",".aif" : "audio/x-aiff",".aifc" : "audio/x-aiff",".aiff" : "audio/x-aiff",
    ".asc" : "text/plain",".au" : "audio/basic",".avi" : "video/x-msvideo",".bcpio" : "application/x-bcpio",".bin" : "application/octet-stream",
    ".bmp" : "image/bmp",".c" : "text/plain",".cc" : "text/plain",".ccad" : "application/clariscad",".cdf" : "application/x-netcdf",
    ".class" : "application/octet-stream", ".com" : "application/octet-stream", ".cpio" : "application/x-cpio",".cpt" : "application/mac-compactpro",".csh" : "application/x-csh",
    ".css" : "text/css",".dcr" : "application/x-director",".dir" : "application/x-director",".dms" : "application/octet-stream",
    ".doc" : "application/msword",".drw" : "application/drafting",".dvi" : "application/x-dvi",".dwg" : "application/acad",
    ".dxf" : "application/dxf",".dxr" : "application/x-director",".eps" : "application/postscript",".etx" : "text/x-setext",
    ".elm" : "message/rfc822",
    ".exe" : "application/octet-stream",".ez" : "application/andrew-inset",".f" : "text/plain",".f90" : "text/plain",".fli" : "video/x-fli",
    ".gif" : "image/gif",".gtar" : "application/x-gtar",".gz" : "application/x-gzip",".h" : "text/plain",".hdf" : "application/x-hdf",
    ".hh" : "text/plain",".hqx" : "application/mac-binhex40",".htm" : "text/html",".html" : "text/html",".ice" : "x-conference/x-cooltalk",
    ".ief" : "image/ief",".iges" : "model/iges",".igs" : "model/iges",".ips" : "application/x-ipscript",".ipx" : "application/x-ipix",
    ".jpe" : "image/jpeg",".jpeg" : "image/jpeg",".jpg" : "image/jpeg",".js" : "application/x-javascript",".kar" : "audio/midi",
    ".latex" : "application/x-latex",".lha" : "application/octet-stream",".lsp" : "application/x-lisp",".lzh" : "application/octet-stream",
    ".m" : "text/plain",".man" : "application/x-troff-man",".me" : "application/x-troff-me",".mesh" : "model/mesh",".mid" : "audio/midi",
    ".midi" : "audio/midi",".mif" : "application/vnd.mif",".mime" : "www/mime",".mov" : "video/quicktime",".movie" : "video/x-sgi-movie",
    ".mp2" : "audio/mpeg",".mp3" : "audio/mpeg",".mpe" : "video/mpeg",".mpeg" : "video/mpeg",".mpg" : "video/mpeg",".mpga" : "audio/mpeg",
    ".ms" : "application/x-troff-ms",".msh" : "model/mesh",".nc" : "application/x-netcdf",".oda" : "application/oda",
    ".pbm" : "image/x-portable-bitmap",".pdb" : "chemical/x-pdb",".pdf" : "application/pdf",".pgm" : "image/x-portable-graymap",
    ".pgn" : "application/x-chess-pgn",".png" : "image/png",".pnm" : "image/x-portable-anymap",".pot" : "application/mspowerpoint",
    ".ppm" : "image/x-portable-pixmap",".pps" : "application/mspowerpoint",".ppt" : "application/mspowerpoint",".ppz" : "application/mspowerpoint",
    ".pre" : "application/x-freelance",".prt" : "application/pro_eng",".ps" : "application/postscript",".qt" : "video/quicktime",
    ".ra" : "audio/x-realaudio",".ram" : "audio/x-pn-realaudio",".ras" : "image/cmu-raster",".rgb" : "image/x-rgb",".rm" : "audio/x-pn-realaudio",
    ".roff" : "application/x-troff",".rpm" : "audio/x-pn-realaudio-plugin",".rtf" : "text/rtf",".rtx" : "text/richtext",
    ".scm" : "application/x-lotusscreencam",".set" : "application/set",".sgm" : "text/sgml",".sgml" : "text/sgml",".sh" : "application/x-sh",
    ".shar" : "application/x-shar",".silo" : "model/mesh",".sit" : "application/x-stuffit",".skd" : "application/x-koan",
    ".skm" : "application/x-koan",".skp" : "application/x-koan",".skt" : "application/x-koan",".smi" : "application/smil",
    ".smil" : "application/smil",".snd" : "audio/basic",".sol" : "application/solids",".spl" : "application/x-futuresplash",
    ".src" : "application/x-wais-source",".step" : "application/STEP",".stl" : "application/SLA",".stp" : "application/STEP",
    ".sv4cpio" : "application/x-sv4cpio",".sv4crc" : "application/x-sv4crc",".swf" : "application/x-shockwave-flash",
    ".t" : "application/x-troff",".tar" : "application/x-tar",".tcl" : "application/x-tcl",".tex" : "application/x-tex",
    ".texi" : "application/x-texinfo",".texinfo" : "application/x-texinfo",".tif" : "image/tiff",".tiff" : "image/tiff",
    ".tr" : "application/x-troff",".tsi" : "audio/TSP-audio",".tsp" : "application/dsptype",".tsv" : "text/tab-separated-values",
    ".txt" : "text/plain",".unv" : "application/i-deas",".ustar" : "application/x-ustar",".vcd" : "application/x-cdlink",
    ".vda" : "application/vda",".viv" : "video/vnd.vivo",".vivo" : "video/vnd.vivo",".vrml" : "model/vrml",".wav" : "audio/x-wav",
    ".wrl" : "model/vrml",".xbm" : "image/x-xbitmap",".xlc" : "application/vnd.ms-excel",".xll" : "application/vnd.ms-excel",
    ".xlm" : "application/vnd.ms-excel",".xls" : "application/vnd.ms-excel",".xlw" : "application/vnd.ms-excel",".xml" : "text/xml",
    ".xpm" : "image/x-xpixmap",".xwd" : "image/x-xwindowdump",".xyz" : "chemical/x-pdb",".wbmp" : "image/vnd.wap.wbmp",".wma" : "audio/x-ms-wma",
    ".wml" : "text/vnd.wap.wml",".wmls" : "text/vnd.wap.wmlscript",".zip" : "application/zip"}

class MultiPartEmail:
    """ 
    Wrapper for mime message 
    """

    def __init__(self,to=[],fromfield='',message_id="MmfMessageId", subject = "Default subject"):
        self.message=email.MIMEMultipart.MIMEMultipart()
        self.fromfield=fromfield
        self.message['From']=fromfield
        #self.message['To'] = to
        self.message['To']=string.join(to,",")
        self.to=to
        self.message['Subject'] = subject

    def addHeader(self,headerName = "X-Defult-Header", headerValue=""):
        self.message[headerName] = headerValue

    def addContentFromFile(self,filename, contentBuffer = None, encoding = None):
        """
        will add the attachment to our message
        """
        file2=os.path.split(filename)[1]
        ext=string.lower(os.path.splitext(file2)[1])
        try:
            (generic_type,specific_type)=Content_Types[ext].split("/")
        except KeyError:
            (generic_type,specific_type)="application/octet-steam".split("/")
        attachment = email.MIMENonMultipart.MIMENonMultipart(generic_type,specific_type+"; name="+file2)
        #attachment = email.MIMENonMultipart.MIMENonMultipart(generic_type,specific_type)
        if contentBuffer == None:
            fp=open(filename,'rb')
            attachment.set_payload(fp.read())
            fp.close()
        else:
            attachment.set_payload(contentBuffer)
        attachment.add_header("Content-Disposition","attachment; filename="+file2)
        attachment.add_header("Content-location",file2)
        attachment.add_header("Content-ID","<"+file2+">")
        if encoding == "quopri":
            email.Encoders.encode_quopri(attachment)
        elif encoding == "7or8bit":
            email.Encoders.encode_7or8bit(attachment)
        else:
            email.Encoders.encode_base64(attachment)
        self.message.attach(attachment)

    def addTexttoMime(self,emailtext):
        """
        will add the text to our message
        """
        self.message.attach( email.MIMEText.MIMEText(emailtext) )
    def addText(self, emailtext):
        self.addTexttoMime(emailtext=emailtext) 
    def addContent(self,fileName, contentBuffer, encoding = None):
        self.addContentFromFile(fileName,contentBuffer, encoding = encoding)
    def set_payload(self,payload, encoding=None):
        self.message.set_payload(payload, encoding)
    def as_string(self):
        return self.message.as_string()
    def get_message(self):
        return self.message

