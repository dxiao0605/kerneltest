#!/usr/bin/env /usr/bin/python

import sys
import socket
import time
import random
import binascii
import threading
import smtplib
import os
import string
import array
import time
import base64
import re
import math
import mimetypes
import socket
from cStringIO import StringIO

import mms.mm1.mm1 as mm1
import mms.mm7.mm7 as mm7
import mms.mm4.mm4 as mm4
import xml.etree.ElementTree as ET
import codecs
import optparse

from messaging.mms.message import *
import commands
import httplib

MM1_PDU = {
   'JPGAndTextRelated':{'Parts':['img.jpg;test.txt'], 'Type':'related'}, 
   'EmptyPart':{'Parts':[], 'Type':'mixed'} 
}

class mms_rbt(object):
   """MMS Client that connect to MMSC in order to send MMS messages"""

   def __init__(self):
      self.s = None
      self.msg_parts = []
      self.transaction_id = 0
      self.delivery_report = True
      self.data_path="data/"
      #self.mm1_msg = mm1.Message()

   def set_mmsc_config(self, hostIP, port):
      self.hostIP = hostIP
      self.port = int(port)

   def __connect_to_mmsc(self, destIp='127.0.0.1', port=8080):
      self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      try:
         self.s.connect((destIp, port))
      except socket.error, e:
         raise AssertionError( "Cannot connect to %s on %d. %d: %s" % (destIp, port, e.args[0], e.args[1]))
      
   def mms_msg_attach_file(self, file_name):
      """
      will add the file attachment to our message
      """
      filename = str(file_name)
      file2=os.path.split(filename)[1]
      ext=string.lower(os.path.splitext(file2)[1])
      try:
         contentType = mm1.Content_Types[ext]
      except KeyError, e:
         contentType = "application/octet-stream"
      
      fname = ""
      try:   
          fh = open(filename,"r")
          fname = fh.name
      except IOError, e:
          print ("Unable to open %s. %d: %s" % (fname, e.args[0], e.args[1]))
          sys.exit(1)
      else:
          fileContent = fh.read()
          fh.close()        
      part = mm1.createSinglePart(contentType = contentType, content = fileContent, fileName = file2, contentId = file2, contentLocationString = file2)
      self.msg_parts.append(part)
      print("added filename %s content type %s to message" % (filename,contentType))

   def mms_msg_add_part(self, content_type, file_name, content_location, content_string):
      part = mm1.createSinglePart(contentType = str(content_type), fileName = str(file_name), contentLocationString = str(content_location), content = str(content_string))
      self.msg_parts.append(part)

   def create_mm1_multipart_mixed(self, file_parts=[], From='', to='', subject='Default Subject', dr='129'):
      print("CREATING MM1 MULTIPART MIXED__________________________")
      print("THE VALUE OF FROM RECEIVED:%s"  %From)
      mms = MMSMessage()
      if to is not None:
         mms.headers['To'] = str(to)
      #mms.headers['To1'] = str(to)
      mms.headers['From'] = str(From)
      mms.headers['Message-Type'] = 'm-send-req'
      mms.headers['Subject'] = str(subject)
      if dr=='128':
         mms.headers['X-Mms-Delivery-Report'] = str(dr)

      mms.headers['Delivery-Report'] = 'Yes'
      mms.headers['Read-Reply'] = 'Yes'

      for file_part in file_parts:
         matches = re.search("(\w+)\W(\w+)(<(\w+)>)?$", file_part)
         if matches:
            print matches.groups()
            file_path = str(self.data_path+matches.group(1) + '.'+ matches.group(2))
            ext = str(matches.group(2))
            if matches.group(4):
               content_id = str(matches.group(4))
            else:
               content_id = None
         else:
            file_path = str(self.data_path+file_part)
            content_id=None
            ext=string.lower(os.path.splitext(file_path)[1])

         print "file path = " + file_path
         if content_id is not None:
            print "content_id =" + content_id

         part = DataPart(str(file_path), content_id)
         
         if ext == '3gp':
            part.content_type = 'video/3gpp'
         
         mms.add_data_part(part)
      
      print 'Created MM1 Multi-Part Mixed Message:'
      self.sent_mm1 = mms
      self.__print_mm1_message(mms)
      self.payload = mms.encode()
      
      #mms.to_file('/home/jinny/data/mms_mixed.txt')

   def create_mm1_multipart_related(self, file_parts=[], From='', to='', subject='', dr='129'):
      mms = MMSMessage()
      if to is not None:
         mms.headers['To'] = str(to)
      #mms.headers['From'] = str(From)
      mms.headers['From'] = str(From)
      mms.headers['Message-Type'] = 'm-send-req'
      mms.headers['Subject'] = str(subject)
      #mms.headers['Date'] = time.time()
      mms.headers['Expiry'] = int(time.time()) + 172800
      print mms.headers['Expiry']
      #mms.headers['Expiry'] = 259199
      
      #if dr=='128':
      #   mms.headers['X-Mms-Delivery-Report'] = str(dr)
         
      mms.headers['Delivery-Report'] = 'Yes'
      mms.headers['Read-Reply'] = 'Yes'

      for page_parts in file_parts:
         page = MMSMessagePage()
         page_part = page_parts.split(";")
         for file_part in page_part:
            matches = re.search("(\w+)\W(\w+)(<(\w+)>)?$", file_part)
            if matches:
               print matches.groups()
               file_path = str(self.data_path+matches.group(1) + '.'+ matches.group(2))
               ext = str(matches.group(2))
               if matches.group(4):
                  content_id = str(matches.group(4))
               else:
                  content_id = None
            else:
               file_path = str(self.data_path+file_part)
               content_id=None
               ext=string.lower(os.path.splitext(file_path)[1])


            print "file path = " + file_path
            print mimetypes.guess_type(file_path)[0]
             
            if content_id is not None:
               print "content_id =" + content_id

            if ext in ['jpeg', 'gif', 'jpg', 'png']:
               page.add_image(file_path, content_id)
            
            if ext in ['txt']:
               with open(file_path, 'r') as f:
                  text = f.read().rstrip('\n')
                  #hex_text = "d09120d0b120d09620d0b60a"
                  #hex_text = "c38761766120"
                  #hex_text = "c38974c3a9"
                  hex_text = "4e6f726d616c"
                  #hex_text = "e282acc2a3246d6f6e6579"
                  #text = binascii.unhexlify(hex_text)
                  text = codecs.decode(hex_text,'hex')
                  page.add_text(text, content_id)
            if ext in ['amr','mp3','mid', 'ogg', 'wav']:
               page.add_audio(file_path, content_id)

            if ext in ['mp4','3gp']:
               page.add_video(file_path, content_id)

         mms.add_page(page)
         
      print 'Created MM1 Multi-Part related Message:'
      self.sent_mm1 = mms
      self.__print_mm1_message(mms)
      self.payload = mms.encode()
      #mms.to_file('/home/jinny/data/mms_related.txt')
         
   def create_mm1_message(self, pdu_varibales, From='', to='', subject='', dr='no'):
      pdu_type = pdu_varibales['Type']
      self.transaction_id = self.transaction_id + 1
      if pdu_type == 'related':
        self.create_mm1_multipart_related(pdu_varibales['Parts'], From, to, subject)
      else:
        self.create_mm1_multipart_mixed(pdu_varibales['Parts'], From, to, subject)
      return self.sent_mm1
 

   def send_mm1_message(self, From=''):
      s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      host_header = str(self.hostIP) + ":" + str(self.port)
      print "host ", self.hostIP
      s.connect((self.hostIP, self.port))
      s.send("POST %s HTTP/1.0\r\n" % '/fcgi-bin/mms_x.fcgi.sh')
      s.send("Content-Type: application/vnd.wap.mms-message\r\n")
      s.send("X-JINNY-CID: %s\r\n" %str(From))
      s.send("Host: %s\r\n" % host_header)
      s.send("Content-Length: %d\r\n\r\n" % len(self.payload))

      s.sendall(self.payload)

      buf = StringIO()

      while True:
          data = s.recv(4096)
          if not data:
              break

          buf.write(data)

      s.close()
      data = buf.getvalue()
      buf.close()

      print "PROXY RESPONSE", data     

   def send_mm1_message1(self, From='', to='', subject=''):
      multiPart = mm1.createMultiPartBody(bodyParts = self.msg_parts)

      mSendReq = mm1.createMSendReq(transactionId='trans'+str(self.transaction_id), multiPartBody = multiPart, fromAddress = str(From))
      httpMm1 = mm1.createHttpMm1Post( postContent = mSendReq, msisdnFrom = str(From) )
      self.__connect_to_mmsc(self.hostIP, self.port)
      self.s.send(httpMm1)
      response = self.s.recv(9000)

   def get_mm1_message(self, url, cid, temp_file):
      #gw_host, gw_port = "212.11.23.23", 7899
      s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      s.connect((self.hostIP, self.port))
      s.send("GET %s HTTP/1.0\r\n" % str(url))
      s.send("X-JINNY-CID: %s\r\n\r\n" %str(cid))

      buf = StringIO()

      while True:
          data = s.recv(4096)
          if not data:
              break

          buf.write(data)

      s.close()
      print 'got data'
      data = buf.getvalue()
      buf.close()

      print 'decoding message'
      mms = MMSMessage.from_binary(data)
      self.received_mm1 = mms
      self.__print_mm1_message(mms)
      return mms

   def get_mm1_message1(self, url, cid, temp_file):
      cmd = 'wget --header="X-JINNY-CID: %s" -O %s "%s" > /dev/null 2>&1' %(str(cid), str(temp_file), str(url))
      os.system(cmd)
      time.sleep(1)
      message = MMSMessage.from_file(temp_file)
      self.__print_mm1_message(message)
      return message

   def mm1_get_header(self, msg, header_name):
      return msg.headers[header_name]

   def mm1_header_should_be(self, msg, header_name, xvalue):
      value = msg.headers[header_name]
      commands.check_value(value, xvalue, header_name)

   def mm1_body_part_data_should_be(self, msg, part_number, xvalue):
      part = msg.data_parts[int(part_number)]
      commands.check_value(part.data, xvalue, 'Part %s data' %part_number)

   def mm1_body_part_header_should_be(self, msg, part_number, header_name, xvalue):
      part = msg.data_parts[int(part_number)]
      value = part.headers[header_name]
      print value
      if type(value) == tuple:
         commands.check_value(value[0], xvalue, header_name)
      else:
         commands.check_value(value, xvalue, header_name)

   def mm1_body_part_sub_header_should_be(self, msg, part_number, header_name, sub_header, xvalue):
      part = msg.data_parts[int(part_number)]
      value = part.headers[header_name]
      if type(value) == tuple:
         parameters = value[1]
         commands.check_value(parameters[sub_header], xvalue, sub_header)
      #else:
         #raise AssertionError('%s is not a sub header', %sub_header)


   def compare_sent_and_received_mm1_messages(self):
      message = self.sent_mm1
      xmsg = self.received_mm1
      print 'Comparing MMS header information:\n------------------------'
      for hdr in message.headers:
        print 'checking header %s' %hdr
        if hdr == 'From':
          continue
        if hdr == 'To':
          continue
        value = message.headers[hdr]
        xvalue = xmsg.headers[hdr]
        if type(value) == tuple:
            print 'Tuple header'
            print '%s: %s' % (hdr, str(value[0]))
            print '%s: %s' % (hdr, str(xvalue[0]))
            commands.check_value(str(value[0]), str(xvalue[0]), str(hdr))
            if len(value[1]) > 0:
                parameters = value[1]
                print '   parameters:'
                for param in parameters:
                    print '      %s: %s' % (param, parameters[param])
        else:
            print '%s: %s' % (hdr, str(message.headers[hdr]))
            print '%s: %s' % (hdr, str(xmsg.headers[hdr]))
            print 'Checking header value: %s' %str(value)
            commands.check_value(str(value), str(xvalue), str(hdr))

      if len(message.pages) > 0:
        self.compare_multipart_related_body_parts()
      else:
        self.compare_multipart_mixed_body_parts()


   def compare_multipart_related_body_parts(self):
      message = self.sent_mm1
      xmsg = self.received_mm1

   def compare_multipart_mixed_body_parts(self):
      message = self.sent_mm1
      xmsg = self.received_mm1
      counter = 0
      for part in message.data_parts:
          xpart = xmsg.data_parts[counter]
          counter += 1
          print '\n  Data part #%d\n  ------------' % counter 
          for hdr in part.headers:
              value = part.headers[hdr]
              xvalue = xpart.headers[hdr]
              if type(value) == tuple:
                  print '  %s: %s' % (hdr, str(value[0]))
                  commands.check_value(str(value[0]), str(xvalue[0]), str(hdr))
                  if len(value[1]) > 0:
                      parameters = value[1]
                      for param in parameters:
                          print '     %s: %s' % (param, parameters[param])
              else:
                  print '  %s: %s' % (hdr, str(part.headers[hdr]))
                  commands.check_value(str(value), str(xvalue), str(hdr))
          print '  Data length: %d bytes' % len(part)
          commands.check_value(str(part.data), str(xpart.data), 'Part Data')
          # In this exxample, we only print the data of text-based data parts
          if part.content_type.startswith('text/'):
              print '  Contents:'
              print '  "%s"' % part.data

   def __print_mm1_message(self, message):
      # Dump header information
      print 'MMS header information:\n------------------------'
      for hdr in message.headers:
        value = message.headers[hdr]
        if type(value) == tuple:
            print '%s: %s' % (hdr, str(value[0]))
            if len(value[1]) > 0:
                parameters = value[1]
                print '   parameters:'
                for param in parameters:
                    print '      %s: %s' % (param, parameters[param])
        else:
            print '%s: %s' % (hdr, str(message.headers[hdr]))
   
      # Dump message body information
      print '\nMMS body information:\n----------------------'
      print 'Number of pages in message: %d' % len(message.pages)
      print 'Number of data parts in message: %d' % len(message.data_parts)
      counter = 0
      if len(message.pages) > 0:
        for page in message.pages:
          counter += 1
          print '\n  Data Page #%d\n  ------------' % counter
          print page
      else:
        for part in message.data_parts:
          counter += 1
          print '\n  Data part #%d\n  ------------' % counter 
          for hdr in part.headers:
              value = part.headers[hdr]
              if type(value) == tuple:
                  print '  %s: %s' % (hdr, str(value[0]))
                  if len(value[1]) > 0:
                      parameters = value[1]
                      for param in parameters:
                          print '     %s: %s' % (param, parameters[param])
              else:
                  print '  %s: %s' % (hdr, str(part.headers[hdr]))
          print '  Data length: %d bytes' % len(part)
          # In this exxample, we only print the data of text-based data parts
          if part.content_type.startswith('text/'):
              print '  Contents:'
              print '  "%s"' % part.data

   def get_id_from_url(self, url):
      delim = 'id='
      pos = url.find(delim) + len(delim)
      return  url[pos:]



   def parse_notification(self, hex_notification):
      delim = 'id='
      print 'Binary notification:'
      print (commands.hex_to_bin(hex_notification),)
      print 'hex_notification %s' %hex_notification
      delim_hex = delim.encode('hex').upper()
      print 'splitting to : %s' %delim_hex
      id_pos = hex_notification.find(delim_hex) + len(delim_hex)
      print id_pos
      id_hex = hex_notification[id_pos:len(hex_notification) - 2]
      print id_hex
      id = id_hex.decode('hex')
      #notification = hex_notification.decode('hex')
      return id

   def parse_mms_notification(self, hex_notification):
      delim = '8C82'
      body_pos = hex_notification.find(delim)
      body_hex = hex_notification[body_pos:]
      message = MMSMessage.from_hex(body_hex)
      self.__print_mm1_message(message)
      return message


   def create_mm7_message(self, destination=['9613083302'], source='9613805822', username='mm7test', file_parts=[], data_path='data/'):  
      #creates the mm7 message
      self.mm7_msg = mm7.MM7(to=destination,fromfield=source,message_id="MmfMessageId", subject = "Default subject", username = username, transactionId = "defaultTransactionId")
      self.msg_parts = []
      self.transaction_id = self.transaction_id + 1
      for file_part in file_parts:
        self.add_mm7_msg_part(data_path+file_part)
      print "created the following MM7 message:\n%s" % self.mm7_msg.as_string()

   def add_mm7_msg_part(self, file_name):
      self.mm7_msg.addContentFromFile(file_name)


   def send_mm7_message(self, url):
      #base64 encode the username and password
      auth = base64.encodestring('%s:%s' % ('mm7test', 'mm7test')).replace('\n', '')
      print auth
      headers = {"Content-type": 'multipart/related;boundary="===============4465919597934615333==";type=text/xml;start="mm7_msg"',
                #"Accept": "text/plain",
                #"SOAPAction": "\"\"",
                "Authorization": "Basic %s" % auth,
      }

      print "sending MM7 message"
      conn = httplib.HTTPConnection(self.hostIP, port = self.port)
      #conn.request("POST", "/mm7/mm7tomms_x.fcgi.sh", self.mm7_msg.getBody(), headers)
      body = self.mm7_msg.getBody()
      delim = '--='
      pos = body.find(delim)
      body = body[pos:]
      print "created the following MM7 message:\n%s" % body
      #conn.request("POST", url, self.mm7_msg.getBody(), headers)
      conn.request("POST", url, body, headers)
      self.r1 = conn.getresponse()
      self.data = self.r1.read()
      time.sleep(1)

   def get_mm7_response(self):
      print "Receiving mm7 response"
      print "status = %s reason = %s " % (self.r1.status, self.r1.reason)
      print "response dict = %s" % self.r1.__dict__
      print "response msg headers = %s" % self.r1.msg.__dict__
      print "len = %s" % self.r1.length
      print "\n\n\ndata = [[[[%s]]]]" % self.data
      print "parsing data"
          
   # def parse_mm7_response(self):
   #    root = ET.fromstring(self.data)
   #    for self.subelement in root:
   #      for self.subsub in self.subelement:
   #        print 'Subelemnt: '
   #        print self.subelement.tag
   #        print 'Subelement Child:'
   #        print self.subsub.tag, self.subsub.attrib, self.subsub.text
   #        #print "subelement text is:", self.subsub.text
   #        print '=============================================================================='
   #        if self.subsub.tag.find("SubmitRsp"):
   #          for self.subsub_child in self.subsub:
   #            print 'Subelement Sub Child:'
   #            print self.subsub_child.tag, self.subsub_child.attrib, self.subsub_child.text
   #            print '***************************************************************************'
   #            if self.subsub_child.tag.find("Status"):
   #              for self.subsub_child_stepchild in self.subsub_child:
   #                print self.subsub_child_stepchild.tag, self.subsub_child_stepchild.attrib, self.subsub_child_stepchild.text
   #                print '-----------------------------------------------------------------------'

   def validate_mm7_response(self, exp_transactionid, exp_status, exp_status_code, exp_version, exp_message_id):
      root = ET.fromstring(self.data)
      for self.subelement in root:
        for self.subsub in self.subelement:
          print 'Subelemnt: '
          print self.subelement.tag, self.subelement.attrib, self.subelement.text
          print 'Subelement Child:'
          print self.subsub.tag
          print self.subsub.tag, self.subsub.attrib, self.subsub.text
          if self.subsub.tag.find("TransactionID") > 0:
            commands.check_value(self.subsub.text.strip(' '), str(exp_transactionid), 'TransactionID')
          print '=============================================================================='
          if self.subsub.tag.find("SubmitRsp") > 0:
            for self.subsub_child in self.subsub:
              print 'Subelement Sub Child:'
              print self.subsub_child.tag, self.subsub_child.attrib, self.subsub_child.text
              print '***************************************************************************'
              if self.subsub_child.tag.find("Status") > 0:
                for self.subsub_child_stepchild in self.subsub_child:
                  print self.subsub_child_stepchild.tag, self.subsub_child_stepchild.attrib, self.subsub_child_stepchild.text
                  if self.subsub_child_stepchild.tag.find("StatusCode") > 0:
                    commands.check_value(self.subsub_child_stepchild.text.strip(' '), str(exp_status_code), 'Status Code')
                  elif self.subsub_child_stepchild.tag.find("StatusText") > 0:
                    commands.check_value(self.subsub_child_stepchild.text.strip(' '), str(exp_status), 'Status Text')
              elif self.subsub_child.tag.find("MM7Version") > 0:
                commands.check_value(self.subsub_child.text.strip(' '), str(exp_version), 'MM7 Version')
              #elif self.subsub_child.tag.find("MessageID") > 0:
                #commands.check_value(self.subsub_child.text.strip(' '), str(exp_message_id), 'Message ID')

   def create_mm4_message(self, fromAddress = '12456@jinny.ie', toAddress = '9613155662@jinnysoftware.com', subject = 'mm4 subject', message = 'test mm4 mesage'):
      self.mm4_msg = mm4.getDefaultMessage(fromAddress, toAddress, subject, message)

   def send_mm4_message(self, mm4Server='', fromAddress = '12456@jinny.ie', toAddress = '9613155662@jinnysoftware.com'):
      print 'Sending MM4 Message to %s...' %str(mm4Server)
      #s = smtplib.SMTP('automation.millennium.com.lb')
      s = smtplib.SMTP(str(mm4Server))
      print 'From Address: %s' %fromAddress
      print 'To Address: %s' %toAddress
      s.sendmail(fromAddress, [toAddress], self.mm4_msg.as_string())
      s.quit()

def parse_arguments():
  parser = optparse.OptionParser(description='MM1 script for sending messages.')

  # Add required arguments
  parser.add_option('-o', '--sender', dest='sender', help='Sender of the message')
  parser.add_option('-t', '--recipient', dest='recipient', help='Recipient of the message')
  parser.add_option('-H', '--host', dest='host', help='MMSC Host')
  parser.add_option('-p', '--port', dest='port', help='Port for the message')
  parser.add_option('-s', '--subject', dest='subject', help='Subject of the message')

  # Parse command-line arguments
  args, _ = parser.parse_args()

  # Check if required arguments are provided
  if not all([args.sender, args.recipient, args.port, args.subject, args.host]):
    print("Error: Missing required arguments.")
    parser.print_help()
    sys.exit(1)

  return args

if __name__ == '__main__':

   # Parse command-line arguments
   args = parse_arguments()

   # Access the arguments
   sender = args.sender
   recipient = args.recipient
   host = args.host
   port = args.port
   subject = args.subject

   # Your logic to use the arguments goes here
   print("Sender:", sender)
   print("Recipient:", recipient)
   print("Host:", host)
   print("Port:", port)
   print("Subject:", subject)

   mms_sim = mms_rbt()

   mms_sim.set_mmsc_config(host, port)
   mms_sim.create_mm1_message(MM1_PDU['JPGAndTextRelated'], sender, recipient, subject,'128')
   mms_sim.send_mm1_message(sender)

